// services/productService.js

const API_BASE_URL = 'http://localhost:4000/api'; // adjust if using env

class ProductService {
  /**
   * Make HTTP request
   * @param {string} url - API endpoint
   * @param {Object} options - fetch options
   * @returns {Promise<Object>} API response
   */
  async request(url, options = {}) {
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(`${API_BASE_URL}${url}`, config);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your connection.');
      }
      throw error;
    }
  }

  /** Get all products */
  async getAll() {
    return this.request('/products');
  }

  /** Get product by ID */
  async getById(id) {
    return this.request(`/products/${id}`);
  }

  /** Get products by type */
  async getByType(type) {
    return this.request(`/products/type/${encodeURIComponent(type)}`);
  }

  /** Get products by name */
  async getByName(name) {
    return this.request(`/products/name/${encodeURIComponent(name)}`);
  }

  /** Get products by brand */
  async getByBrand(brand) {
    return this.request(`/products/brand/${encodeURIComponent(brand)}`);
  }

  /** Get available products */
  async getAvailable(available = true) {
    return this.request(`/products/available/${available}`);
  }

  /** Create a new product */
  async create(productData) {
    return this.request('/products', {
      method: 'POST',
      body: JSON.stringify(productData)
    });
  }

  /** Update a product by ID */
  async updateById(id, productData) {
    return this.request(`/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(productData)
    });
  }

  /** Update a product by Name */
  async updateByName(name, productData) {
    return this.request(`/products/name/${encodeURIComponent(name)}`, {
      method: 'PUT',
      body: JSON.stringify(productData)
    });
  }

  /** Delete a product by ID */
  async deleteById(id) {
    return this.request(`/products/${id}`, { method: 'DELETE' });
  }

  /** Delete a product by Name */
  async deleteByName(name) {
    return this.request(`/products/name/${encodeURIComponent(name)}`, { method: 'DELETE' });
  }

  /** Delete a product by Type */
  async deleteByType(type) {
    return this.request(`/products/type/${encodeURIComponent(type)}`, { method: 'DELETE' });
  }
}

// Export singleton instance
export const productService = new ProductService();
