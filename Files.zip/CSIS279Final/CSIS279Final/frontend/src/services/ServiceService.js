// services/ServiceService.js

const API_BASE_URL = 'http://localhost:4000/api'; // adjust if using env

class ServiceService {
  /** Centralized HTTP request */
  async request(url, options = {}) {
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(`${API_BASE_URL}${url}`, config);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your connection.');
      }
      throw error;
    }
  }

  /** List all services */
  async getAll() {
    return this.request('/services');
  }

  /** Get service by ID */
  async getById(id) {
    return this.request(`/services/${id}`);
  }

  /** Get services by type */
  async getByType(type) {
    return this.request(`/services/type/${encodeURIComponent(type)}`);
  }

  /** Get services by name */
  async getByName(name) {
    return this.request(`/services/name/${encodeURIComponent(name)}`);
  }

  /** Get available services */
  async getAvailable(available = true) {
    return this.request(`/services/available/${available}`);
  }

  /** Create a new service */
  async create(serviceData) {
    return this.request('/services', {
      method: 'POST',
      body: JSON.stringify(serviceData)
    });
  }

  /** Update service by ID */
  async updateById(id, serviceData) {
    return this.request(`/services/${id}`, {
      method: 'PUT',
      body: JSON.stringify(serviceData)
    });
  }

  /** Update service by name */
  async updateByName(name, serviceData) {
    return this.request(`/services/name/${encodeURIComponent(name)}`, {
      method: 'PUT',
      body: JSON.stringify(serviceData)
    });
  }

  /** Update service by type */
  async updateByType(type, serviceData) {
    return this.request(`/services/type/${encodeURIComponent(type)}`, {
      method: 'PUT',
      body: JSON.stringify(serviceData)
    });
  }

  /** Delete service by ID */
  async deleteById(id) {
    return this.request(`/services/${id}`, { method: 'DELETE' });
  }

  /** Delete service by name */
  async deleteByName(name) {
    return this.request(`/services/name/${encodeURIComponent(name)}`, { method: 'DELETE' });
  }

  /** Delete service by type */
  async deleteByType(type) {
    return this.request(`/services/type/${encodeURIComponent(type)}`, { method: 'DELETE' });
  }
}

// Export singleton instance
export const serviceService = new ServiceService();
