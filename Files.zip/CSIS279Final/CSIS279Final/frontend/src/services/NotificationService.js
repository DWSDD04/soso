// services/notificationService.js

const API_BASE_URL = 'http://localhost:4000/api'; // adjust if using env

class NotificationService {
  /**
   * Make HTTP request
   * @param {string} url - API endpoint
   * @param {Object} options - fetch options
   * @returns {Promise<Object>} API response
   */
  async request(url, options = {}) {
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(`${API_BASE_URL}${url}`, config);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      // 204 No Content returns empty body
      if (response.status === 204) return null;

      return await response.json();
    } catch (error) {
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your connection.');
      }
      throw error;
    }
  }

  /** Get all notifications */
  async getAll() {
    return this.request('/notifications');
  }

  /** Get notification by ID */
  async getById(id) {
    return this.request(`/notifications/${id}`);
  }

  /** Get notifications by AppointmentID */
  async getByAppointmentId(appointmentId) {
    return this.request(`/notifications/appointment/${appointmentId}`);
  }

  /** Get notifications by date range */
  async getByDateRange(startDate, endDate) {
    const query = `?startDate=${encodeURIComponent(startDate)}&endDate=${encodeURIComponent(endDate)}`;
    return this.request(`/notifications/date-range/byDateRange${query}`);
  }

  /** Create a new notification */
  async create(data) {
    return this.request('/notifications', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  /** Update notification by ID */
  async updateById(id, data) {
    return this.request(`/notifications/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  }

  /** Update notifications by AppointmentID */
  async updateByAppointmentId(appointmentId, data) {
    return this.request(`/notifications/appointment/${appointmentId}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  }

  /** Update notifications by date range */
  async updateByDateRange(startDate, endDate, data) {
    return this.request('/notifications/update-date-range', {
      method: 'PUT',
      body: JSON.stringify({ startDate, endDate, ...data })
    });
  }

  /** Delete notification by ID */
  async deleteById(id) {
    return this.request(`/notifications/${id}`, { method: 'DELETE' });
  }

  /** Delete notifications by AppointmentID */
  async deleteByAppointmentId(appointmentId) {
    return this.request(`/notifications/appointment/${appointmentId}`, { method: 'DELETE' });
  }

  /** Delete notifications by date range */
  async deleteByDateRange(startDate, endDate) {
    return this.request('/notifications/delete-date-range', {
      method: 'DELETE',
      body: JSON.stringify({ startDate, endDate })
    });
  }

  /** Count notifications */
  async count() {
    return this.request('/notifications/count');
  }
}

// Export singleton instance
export const notificationService = new NotificationService();
