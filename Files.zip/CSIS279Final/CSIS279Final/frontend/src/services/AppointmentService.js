// services/AppointmentService.js

const API_BASE_URL = 'http://localhost:4000/api'; // adjust if using env

class AppointmentService {
  /** Centralized HTTP request */
  async request(url, options = {}) {
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(`${API_BASE_URL}${url}`, config);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your connection.');
      }
      throw error;
    }
  }

  /** List all appointments */
  async getAll() {
    return this.request('/appointments');
  }

  /** Get appointment by ID */
  async getById(id) {
    return this.request(`/appointments/${id}`);
  }

  /** Create a new appointment */
  async create(appointmentData) {
    return this.request('/appointments', {
      method: 'POST',
      body: JSON.stringify(appointmentData)
    });
  }

  /** Update appointment by ID */
  async updateById(id, appointmentData) {
    return this.request(`/appointments/${id}`, {
      method: 'PUT',
      body: JSON.stringify(appointmentData)
    });
  }

  /** Delete appointment by ID */
  async deleteById(id) {
    return this.request(`/appointments/${id}`, { method: 'DELETE' });
  }

  /** Get appointments by service ID */
  async getByServiceId(serviceId) {
    return this.request(`/appointments/service/${serviceId}`);
  }

  /** Get appointments by status */
  async getByStatus(status) {
    return this.request(`/appointments/status/${encodeURIComponent(status)}`);
  }

  /** Get today's appointments */
  async getToday() {
    return this.request('/appointments/today');
  }

  /** Get upcoming appointments */
  async getUpcoming() {
    return this.request('/appointments/upcoming');
  }

  /** Get appointments by date range */
  async getByDateRange(startDate, endDate) {
    const query = `?start=${encodeURIComponent(startDate)}&end=${encodeURIComponent(endDate)}`;
    return this.request(`/appointments/range${query}`);
  }
}

// Export singleton instance
export const appointmentService = new AppointmentService();
