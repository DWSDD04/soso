// services/UserService.js

const API_BASE_URL = 'http://localhost:4000/api'; // adjust if using env

class UserService {
  /** Centralized HTTP request */
  async request(url, options = {}) {
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    try {
      const response = await fetch(`${API_BASE_URL}${url}`, config);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error('Network error. Please check your connection.');
      }
      throw error;
    }
  }

  /** List all users */
  async getAll() {
    return this.request('/users');
  }

  /** Get user by ID */
  async getById(id) {
    return this.request(`/users/${id}`);
  }

  /** Get user by Email */
  async getByEmail(email) {
    return this.request(`/users/email/${encodeURIComponent(email)}`);
  }

  /** Get users by status */
  async getByStatus(status) {
    return this.request(`/users/status/${encodeURIComponent(status)}`);
  }

  /** Create new user */
  async create(userData) {
    return this.request('/users', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  }

  /** Update user by ID */
  async updateById(id, userData) {
    return this.request(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(userData)
    });
  }

  /** Update user by Email */
  async updateByEmail(email, userData) {
    return this.request(`/users/email/${encodeURIComponent(email)}`, {
      method: 'PUT',
      body: JSON.stringify(userData)
    });
  }

  /** Delete user by ID */
  async deleteById(id) {
    return this.request(`/users/${id}`, { method: 'DELETE' });
  }

  /** Delete user by Email */
  async deleteByEmail(email) {
    return this.request(`/users/email/${encodeURIComponent(email)}`, { method: 'DELETE' });
  }

  /** Count total users */
  async countTotal() {
    return this.request('/users/count/total');
  }
}

// Export singleton instance
export const userService = new UserService();
