import { IsInt, IsPositive } from 'class-validator';

export class CreateProductServiceDto {
  @IsInt()
  @IsPositive()
  ProductID: number;

  @IsInt()
  @IsPositive()
  ServiceID: number;

  @IsInt()
  @IsPositive()
  Quantity: number;
}
