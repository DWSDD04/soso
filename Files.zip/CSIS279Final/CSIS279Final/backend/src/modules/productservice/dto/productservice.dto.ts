export class ProductServiceDto {
  ProductID: number;
  ServiceID: number;
  Quantity: number;

  constructor(ProductID: number, ServiceID: number, Quantity: number) {
    this.ProductID = ProductID;
    this.ServiceID = ServiceID;
    this.Quantity = Quantity;
  }

  static fromEntity(entity: any): ProductServiceDto {
  if (!entity) throw new Error("Cannot convert null entity"); // or throw NotFoundException
  return new ProductServiceDto(
    entity.ProductID,
    entity.ServiceID,
    entity.Quantity
  );
}


  static fromEntities(entities: any[]): ProductServiceDto[] {
    if (!Array.isArray(entities)) return [];
    return entities
      .map((e) => ProductServiceDto.fromEntity(e))
      .filter((x): x is ProductServiceDto => x !== null);
  }
}
