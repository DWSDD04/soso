import { IsInt, IsPositive, IsOptional } from 'class-validator';

export class UpdateProductServiceDto {
  @IsInt()
  @IsPositive()
  @IsOptional()
  ProductID?: number;

  @IsInt()
  @IsPositive()
  @IsOptional()
  ServiceID?: number;

  @IsInt()
  @IsPositive()
  @IsOptional()
  Quantity?: number;
}
