import { IsInt, IsPositive } from 'class-validator';

export class ProductServiceParamsDto {
  @IsInt()
  @IsPositive()
  id: number;
}
