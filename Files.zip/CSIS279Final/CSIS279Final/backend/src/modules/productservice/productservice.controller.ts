import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  HttpCode,
  NotFoundException,
  ConflictException,
  UsePipes,
  ValidationPipe,
  ParseIntPipe,
  BadRequestException,
} from '@nestjs/common';
import { ProductServiceService } from './productservice.service';
import { CreateProductServiceDto } from './dto/create-productservice.dto';
import { UpdateProductServiceDto } from './dto/update-productservice.dto';
import { ProductServiceDto } from './dto/productservice.dto';

@Controller('productservice')
@UsePipes(new ValidationPipe({ transform: true, whitelist: true }))
export class ProductServiceController {
  constructor(private readonly productServiceService: ProductServiceService) {}

  // =====================
  // CREATE / ADD
  // =====================

  // POST /productservice
  @Post()
  async create(@Body() body: CreateProductServiceDto): Promise<ProductServiceDto> {
    try {
      const { ServiceID, ProductID, Quantity } = body;
      const created = await this.productServiceService.addProductToService(
        ServiceID,
        ProductID,
        Quantity ?? 1.0,
      );
      return created;
    } catch (err) {
      // If service throws BadRequestException for "already associated",
      // allow it to pass through (Nest will convert to 400).
      // Convert generic errors to Conflict if message indicates duplicate association.
      if (err instanceof BadRequestException && String(err.message).includes('already associated')) {
        throw new ConflictException(err.message);
      }
      throw err;
    }
  }

  // POST /productservice/service/:ServiceID   (add a product to a specific service)
  @Post('service/:ServiceID')
  async addProductToService(
    @Param('ServiceID', ParseIntPipe) ServiceID: number,
    @Body('ProductID', ParseIntPipe) ProductID: number,
    @Body('Quantity') Quantity?: number,
  ): Promise<ProductServiceDto> {
    try {
      return await this.productServiceService.addProductToService(
        ServiceID,
        ProductID,
        Quantity ?? 1.0,
      );
    } catch (err) {
      if (err instanceof BadRequestException && String(err.message).includes('already associated')) {
        throw new ConflictException(err.message);
      }
      throw err;
    }
  }

  // POST /productservice/product/:ProductID   (add a service to a specific product)
  @Post('product/:ProductID')
  async addServiceToProduct(
    @Param('ProductID', ParseIntPipe) ProductID: number,
    @Body('ServiceID', ParseIntPipe) ServiceID: number,
    @Body('Quantity') Quantity?: number,
  ): Promise<ProductServiceDto> {
    try {
      return await this.productServiceService.addServiceToProduct(
        ServiceID,
        ProductID,
        Quantity ?? 1.0,
      );
    } catch (err) {
      if (err instanceof BadRequestException && String(err.message).includes('already associated')) {
        throw new ConflictException(err.message);
      }
      throw err;
    }
  }

  // =====================
  // UPDATE
  // =====================

  // PUT /productservice/:ServiceID/:ProductID
  @Put(':ServiceID/:ProductID')
  async updateProductService(
    @Param('ServiceID', ParseIntPipe) ServiceID: number,
    @Param('ProductID', ParseIntPipe) ProductID: number,
    @Body() updateDto: UpdateProductServiceDto,
  ): Promise<{ affected?: boolean }> {
    await this.productServiceService.updateProductService(ServiceID, ProductID, updateDto);
    return { affected: true };
  }

  // PUT /productservice/product/:ProductID
  @Put('product/:ProductID')
  async updateByProduct(
    @Param('ProductID', ParseIntPipe) ProductID: number,
    @Body() updateDto: UpdateProductServiceDto,
  ): Promise<{ affected?: boolean }> {
    await this.productServiceService.updateByProduct(ProductID, updateDto);
    return { affected: true };
  }

  // PUT /productservice/service/:ServiceID
  @Put('service/:ServiceID')
  async updateByService(
    @Param('ServiceID', ParseIntPipe) ServiceID: number,
    @Body() updateDto: UpdateProductServiceDto,
  ): Promise<{ affected?: boolean }> {
    await this.productServiceService.updateByService(ServiceID, updateDto);
    return { affected: true };
  }

  // =====================
  // FETCH
  // =====================

  // GET /productservice
  @Get()
  async getAll(): Promise<ProductServiceDto[]> {
    return await this.productServiceService.getAllProductServices();
  }

  // GET /productservice/:ServiceID/:ProductID
  @Get(':ServiceID/:ProductID')
  async getByServiceAndProduct(
    @Param('ServiceID', ParseIntPipe) ServiceID: number,
    @Param('ProductID', ParseIntPipe) ProductID: number,
  ): Promise<ProductServiceDto> {
    const row = await this.productServiceService.getByServiceAndProduct(ServiceID, ProductID);
    if (!row) throw new NotFoundException('Relationship not found');
    return row;
  }

  // GET /productservice/service/:ServiceID
  @Get('service/:ServiceID')
  async getProductsForService(@Param('ServiceID', ParseIntPipe) ServiceID: number): Promise<ProductServiceDto[]> {
    return await this.productServiceService.getProductsForService(ServiceID);
  }

  // GET /productservice/product/:ProductID
  @Get('product/:ProductID')
  async getServicesForProduct(@Param('ProductID', ParseIntPipe) ProductID: number): Promise<ProductServiceDto[]> {
    return await this.productServiceService.getServicesForProduct(ProductID);
  }

  // =====================
  // DELETE
  // =====================

  // DELETE /productservice/:ServiceID/:ProductID
  @Delete(':ServiceID/:ProductID')
  async deleteProductService(
    @Param('ServiceID', ParseIntPipe) ServiceID: number,
    @Param('ProductID', ParseIntPipe) ProductID: number,
  ): Promise<{ deleted: boolean }> {
    await this.productServiceService.deleteProductService(ServiceID, ProductID);
    return { deleted: true };
  }

  // DELETE /productservice/service/:ServiceID
  @Delete('service/:ServiceID')
  async deleteByService(@Param('ServiceID', ParseIntPipe) ServiceID: number): Promise<{ deleted: boolean }> {
    await this.productServiceService.deleteByService(ServiceID);
    return { deleted: true };
  }

  // DELETE /productservice/product/:ProductID
  @Delete('product/:ProductID')
  async deleteByProduct(@Param('ProductID', ParseIntPipe) ProductID: number): Promise<{ deleted: boolean }> {
    await this.productServiceService.deleteByProduct(ProductID);
    return { deleted: true };
  }

  // DELETE /productservice/quantity/:Quantity
  @Delete('quantity/:Quantity')
  async deleteByQuantity(@Param('Quantity', ParseIntPipe) Quantity: number): Promise<{ deleted: boolean }> {
    await this.productServiceService.deleteByQuantity(Quantity);
    return { deleted: true };
  }
}
