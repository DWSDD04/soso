import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { ProductServiceRepository } from './repositories/productservice.repository';
import { ProductServiceDto } from './dto/productservice.dto';

@Injectable()
export class ProductServiceService {
  constructor(
    private readonly productServiceRepository: ProductServiceRepository,
  ) {}

  // =====================
  // FETCH
  // =====================
  async getAllProductServices(): Promise<ProductServiceDto[]> {
    const entities = await this.productServiceRepository.getAllProductServices();
    return ProductServiceDto.fromEntities(entities);
  }

  async getByServiceAndProduct(
  ServiceID: number,
  ProductID: number,
): Promise<ProductServiceDto | null> {  
  const entity = await this.productServiceRepository.getByServiceAndProduct(ServiceID, ProductID);
  return entity ? ProductServiceDto.fromEntity(entity) : null;
}


  async getProductsForService(ServiceID: number): Promise<ProductServiceDto[]> {
    const entities = await this.productServiceRepository.getProductsForService(ServiceID);
    return ProductServiceDto.fromEntities(entities);
  }

  async getServicesForProduct(ProductID: number): Promise<ProductServiceDto[]> {
    const entities = await this.productServiceRepository.getServicesForProduct(ProductID);
    return ProductServiceDto.fromEntities(entities);
  }

  // =====================
  // CREATE
  // =====================
  async addProductToService(
    ServiceID: number,
    ProductID: number,
    Quantity = 1.0,
  ): Promise<ProductServiceDto> {
    const existing = await this.productServiceRepository.getByServiceAndProduct(ServiceID, ProductID);
    if (existing) {
      throw new BadRequestException('This product is already associated with the service');
    }

    const entity = await this.productServiceRepository.createProductService(
      new ProductServiceDto(ProductID, ServiceID, Quantity),
    );
    return ProductServiceDto.fromEntity(entity);
  }

  async addServiceToProduct(
    ServiceID: number,
    ProductID: number,
    Quantity = 1.0,
  ): Promise<ProductServiceDto> {
    // same logic as addProductToService
    return this.addProductToService(ServiceID, ProductID, Quantity);
  }

  // =====================
  // UPDATE
  // =====================
  async updateProductService(
    ServiceID: number,
    ProductID: number,
    updateData: Partial<ProductServiceDto>,
  ): Promise<void> {
    await this.productServiceRepository.updateProductService(ServiceID, ProductID, updateData);
  }

  async updateByProduct(ProductID: number, updateData: Partial<ProductServiceDto>): Promise<void> {
    await this.productServiceRepository.updateByProduct(ProductID, updateData);
  }

  async updateByService(ServiceID: number, updateData: Partial<ProductServiceDto>): Promise<void> {
    await this.productServiceRepository.updateByService(ServiceID, updateData);
  }

  // ✅ Removed updateByQuantity because the repository does not have it
  // If you want it, you need to implement `updateByQuantity` in ProductServiceRepository

  // =====================
  // DELETE
  // =====================
  async deleteProductService(ServiceID: number, ProductID: number): Promise<void> {
    await this.productServiceRepository.deleteProductService(ServiceID, ProductID);
  }

  async deleteByService(ServiceID: number): Promise<void> {
    await this.productServiceRepository.deleteByService(ServiceID);
  }

  async deleteByProduct(ProductID: number): Promise<void> {
    await this.productServiceRepository.deleteByProduct(ProductID);
  }

  async deleteByQuantity(Quantity: number): Promise<void> {
    await this.productServiceRepository.deleteByQuantity(Quantity);
  }
}
