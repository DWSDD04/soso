// productservice.repository.ts
import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ProductService } from '../entities/productservice.entity';
import { ProductServiceDto } from '../dto/productservice.dto';

@Injectable()
export class ProductServiceRepository {
  constructor(
    @InjectRepository(ProductService)
    private readonly repo: Repository<ProductService>,
  ) {}

  // CREATE
  async createProductService(dto: ProductServiceDto): Promise<ProductService> {
    const entity = this.repo.create({
      ProductID: dto.ProductID,
      ServiceID: dto.ServiceID,
      Quantity: dto.Quantity ?? 1,
    });
    return this.repo.save(entity);
  }

  // READ
  async getAllProductServices(): Promise<ProductService[]> {
    return this.repo.find();
  }

  async getByServiceAndProduct(
    ServiceID: number,
    ProductID: number,
  ): Promise<ProductService | null> {
    return this.repo.findOne({ where: { ServiceID, ProductID } });
  }

  async getProductsForService(ServiceID: number): Promise<ProductService[]> {
    return this.repo.find({ where: { ServiceID } });
  }

  async getServicesForProduct(ProductID: number): Promise<ProductService[]> {
    return this.repo.find({ where: { ProductID } });
  }

  // UPDATE
  async updateProductService(
    ServiceID: number,
    ProductID: number,
    updateData: Partial<ProductServiceDto>,
  ): Promise<void> {
    await this.repo.update({ ServiceID, ProductID }, updateData);
  }

  async updateByProduct(
    ProductID: number,
    updateData: Partial<ProductServiceDto>,
  ): Promise<void> {
    await this.repo.update({ ProductID }, updateData);
  }

  async updateByService(
    ServiceID: number,
    updateData: Partial<ProductServiceDto>,
  ): Promise<void> {
    await this.repo.update({ ServiceID }, updateData);
  }

  // DELETE
  async deleteProductService(
    ServiceID: number,
    ProductID: number,
  ): Promise<void> {
    await this.repo.delete({ ServiceID, ProductID });
  }

  async deleteByService(ServiceID: number): Promise<void> {
    await this.repo.delete({ ServiceID });
  }

  async deleteByProduct(ProductID: number): Promise<void> {
    await this.repo.delete({ ProductID });
  }

  async deleteByQuantity(Quantity: number): Promise<void> {
    await this.repo.delete({ Quantity });
  }
}
