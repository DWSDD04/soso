import { IsInt, IsPositive, Validate } from 'class-validator';
import { ProductExists, ServiceExists } from './productservice-exists.validator';

export class ValidateProductServiceCreate {
  @IsInt({ message: 'ServiceID must be an integer' })
  @IsPositive({ message: 'ServiceID must be a positive integer' })
  @Validate(ServiceExists)
  ServiceID: number;

  @IsInt({ message: 'ProductID must be an integer' })
  @IsPositive({ message: 'ProductID must be a positive integer' })
  @Validate(ProductExists)
  ProductID: number;

  @IsPositive({ message: 'Quantity must be positive (min 0.01)' })
  Quantity: number;
}
