import { IsOptional, IsPositive } from 'class-validator';

export class ValidateProductServiceUpdate {
  @IsOptional()
  @IsPositive({ message: 'Quantity must be positive (min 0.01)' })
  Quantity?: number;
}
