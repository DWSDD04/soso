import { ValidatorConstraint, ValidatorConstraintInterface, ValidationArguments } from 'class-validator';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Product } from '../../product/entities/product.entity';
import { Service } from '../../service/entities/service.entity';

@ValidatorConstraint({ name: 'ProductExists', async: true })
@Injectable()
export class ProductExists implements ValidatorConstraintInterface {
  constructor(
    @InjectRepository(Product)
    private readonly productRepo: Repository<Product>,
  ) {}

  async validate(ProductID: number) {
    const exists = await this.productRepo.findOne({ where: { ProductID } });
    return !!exists;
  }

  defaultMessage(args: ValidationArguments) {
    return `Product with ID ${args.value} does not exist`;
  }
}

@ValidatorConstraint({ name: 'ServiceExists', async: true })
@Injectable()
export class ServiceExists implements ValidatorConstraintInterface {
  constructor(
    @InjectRepository(Service)
    private readonly serviceRepo: Repository<Service>,
  ) {}

  async validate(ServiceID: number) {
    const exists = await this.serviceRepo.findOne({ where: { ServiceID } });
    return !!exists;
  }

  defaultMessage(args: ValidationArguments) {
    return `Service with ID ${args.value} does not exist`;
  }
}
