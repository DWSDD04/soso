import { IsInt, IsPositive, Validate } from 'class-validator';
import { ProductExists, ServiceExists } from './productservice-exists.validator';

export class ValidateServiceIDParam {
  @IsInt()
  @IsPositive()
  @Validate(ServiceExists)
  ServiceID: number;
}

export class ValidateProductIDParam {
  @IsInt()
  @IsPositive()
  @Validate(ProductExists)
  ProductID: number;
}

export class ValidateServiceAndProductIDs {
  @IsInt()
  @IsPositive()
  @Validate(ServiceExists)
  ServiceID: number;

  @IsInt()
  @IsPositive()
  @Validate(ProductExists)
  ProductID: number;
}
