// src/modules/productservice/productservice.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { ProductService } from './entities/productservice.entity';
import { Product } from '../product/entities/product.entity';
import { Service } from '../service/entities/service.entity';

import { ProductServiceRepository } from './repositories/productservice.repository';
import { ProductServiceService } from './productservice.service';
import { ProductServiceController } from './productservice.controller';

import { ProductExists, ServiceExists } from './validators/productservice-exists.validator';

@Module({
  imports: [TypeOrmModule.forFeature([ProductService, Product, Service])],
  controllers: [ProductServiceController],
  providers: [
    ProductServiceService,
    ProductServiceRepository,
    ProductExists,
    ServiceExists,
  ],
  exports: [
    ProductServiceService,
    ProductServiceRepository,
  ],
})
export class ProductServiceModule {}
