import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('product_service')
export class ProductService {
  @PrimaryGeneratedColumn()
  ID: number;

  @Column()
  ProductID: number;

  @Column()
  ServiceID: number;

  @Column('int')
  Quantity: number;

  constructor(ProductID?: number, ServiceID?: number, Quantity?: number) {
    if (ProductID !== undefined) this.ProductID = ProductID;
    if (ServiceID !== undefined) this.ServiceID = ServiceID;
    if (Quantity !== undefined) this.Quantity = Quantity;
  }
}
