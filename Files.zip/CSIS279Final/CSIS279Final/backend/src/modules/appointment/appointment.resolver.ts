// src/modules/appointment/appointment.resolver.ts
import { Resolver, Query, Mutation, Args, Int } from '@nestjs/graphql';
import { NotFoundException } from '@nestjs/common';

import { AppointmentService } from './appointment.service';
import { AppointmentDTO } from './dto/appointment.dto';
import { CreateAppointmentDTO } from './dto/create-appointment.dto';
import { UpdateAppointmentDTO } from './dto/update-appointment.dto';

@Resolver(() => AppointmentDTO)
export class AppointmentResolver {
  constructor(private readonly appointmentService: AppointmentService) {}

  // ===============================
  // GET ALL
  // ===============================
  @Query(() => [AppointmentDTO], { name: 'appointments' })
  async listAppointments(): Promise<AppointmentDTO[]> {
    return this.appointmentService.listAppointments();
  }

  // ===============================
  // GET BY ID
  // ===============================
  @Query(() => AppointmentDTO, { name: 'appointment', nullable: true })
  async getAppointmentByID(
    @Args('id', { type: () => Int }) id: number,
  ): Promise<AppointmentDTO | null> {
    const appointment = await this.appointmentService.getAppointmentByID(id);
    if (!appointment) {
      throw new NotFoundException(`Appointment with ID ${id} not found`);
    }
    return appointment;
  }

  // ===============================
  // GET BY SERVICE ID
  // ===============================
  @Query(() => [AppointmentDTO], { name: 'appointmentsByService', nullable: 'itemsAndList' })
  async getAppointmentsByService(
    @Args('serviceID', { type: () => Int }) serviceID: number,
  ): Promise<AppointmentDTO[]> {
    return this.appointmentService.getAppointmentsByService(serviceID);
  }

  // ===============================
  // GET BY STATUS
  // ===============================
  @Query(() => [AppointmentDTO], { name: 'appointmentsByStatus', nullable: 'itemsAndList' })
  async getAppointmentsByStatus(@Args('status') status: string): Promise<AppointmentDTO[]> {
    return this.appointmentService.getAppointmentsByStatus(status);
  }

  // ===============================
  // GET UPCOMING
  // ===============================
  @Query(() => [AppointmentDTO], { name: 'upcomingAppointments', nullable: 'itemsAndList' })
  async getUpcomingAppointments(): Promise<AppointmentDTO[]> {
    return this.appointmentService.getUpcomingAppointments();
  }

  // ===============================
  // GET BY DATE RANGE
  // ===============================
  @Query(() => [AppointmentDTO], { name: 'appointmentsByDateRange', nullable: 'itemsAndList' })
  async getAppointmentsByDateRange(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
  ): Promise<AppointmentDTO[]> {
    return this.appointmentService.getAppointmentsByDateRange(startDate, endDate);
  }

  // ===============================
  // CREATE
  // ===============================
  @Mutation(() => AppointmentDTO, { name: 'createAppointment' })
  async createAppointment(
    @Args('data') data: CreateAppointmentDTO,
  ): Promise<AppointmentDTO> {
    const created = await this.appointmentService.createAppointment(data);
    if (!created) throw new NotFoundException('Failed to create appointment');
    return created;
  }

  // ===============================
  // UPDATE BY ID
  // ===============================
  @Mutation(() => AppointmentDTO, { name: 'updateAppointmentByID' })
  async updateAppointmentByID(
    @Args('id', { type: () => Int }) id: number,
    @Args('data') data: UpdateAppointmentDTO,
  ): Promise<AppointmentDTO> {
    const updated = await this.appointmentService.updateAppointmentByID(id, data);
    if (!updated) throw new NotFoundException(`Appointment with ID ${id} not found`);
    return updated;
  }

  // ===============================
  // DELETE BY ID
  // ===============================
  @Mutation(() => Boolean, { name: 'deleteAppointmentByID' })
  async deleteAppointmentByID(
    @Args('id', { type: () => Int }) id: number,
  ): Promise<boolean> {
    return this.appointmentService.deleteAppointmentByID(id);
  }
}
