import { Injectable, NotFoundException } from '@nestjs/common';
import { AppointmentRepository } from './repositories/appointment.repository';
import { ServiceRepository } from '../service/repositories/service.repository';
import { IncomeRepository } from '../income/repositories/income.repository';
import { AppointmentDTO } from './dto/appointment.dto';
import { CreateAppointmentDTO } from './dto/create-appointment.dto';
import { UpdateAppointmentDTO } from './dto/update-appointment.dto';

@Injectable()
export class AppointmentService {
  constructor(
    private readonly appointmentRepository: AppointmentRepository,
    private readonly serviceRepository: ServiceRepository,
    private readonly incomeRepository: IncomeRepository,
  ) {}

  // =====================
  // GET by ID
  // =====================
  async getAppointmentByID(id: number): Promise<AppointmentDTO> {
    const appointment = await this.appointmentRepository.getAppointmentByID(id);
    if (!appointment) throw new NotFoundException(`Appointment ${id} not found`);
    return AppointmentDTO.fromEntity(appointment);
  }

  // =====================
  // LIST all
  // =====================
  async listAppointments(): Promise<AppointmentDTO[]> {
    const appointments = await this.appointmentRepository.getAllAppointments();
    return appointments.map(a => AppointmentDTO.fromEntity(a));
  }

  // =====================
  // GET by ServiceID
  // =====================
  async getAppointmentsByService(serviceID: number): Promise<AppointmentDTO[]> {
    const appointments = await this.appointmentRepository.getAppointmentsByService(serviceID);
    return appointments.map(a => AppointmentDTO.fromEntity(a));
  }

  // =====================
  // GET by Status
  // =====================
  async getAppointmentsByStatus(status: string): Promise<AppointmentDTO[]> {
    const appointments = await this.appointmentRepository.getAppointmentsByStatus(status);
    return appointments.map(a => AppointmentDTO.fromEntity(a));
  }

  // =====================
  // GET upcoming appointments
  // =====================
  async getUpcomingAppointments(): Promise<AppointmentDTO[]> {
    const appointments = await this.appointmentRepository.getUpcomingAppointments();
    return appointments.map(a => AppointmentDTO.fromEntity(a));
  }

  // =====================
  // GET by Date Range
  // =====================
  async getAppointmentsByDateRange(start: string, end: string): Promise<AppointmentDTO[]> {
    const appointments = await this.appointmentRepository.getAppointmentsByDateRange(start, end);
    return appointments.map(a => AppointmentDTO.fromEntity(a));
  }

  // =====================
  // CREATE
  // =====================
  async createAppointment(data: CreateAppointmentDTO): Promise<AppointmentDTO> {
    const created = await this.appointmentRepository.createAppointment(data);
    return AppointmentDTO.fromEntity(created);
  }

  // =====================
  // UPDATE by ID
  // =====================
  async updateAppointmentByID(id: number, data: UpdateAppointmentDTO): Promise<AppointmentDTO> {
    const existing = await this.appointmentRepository.getAppointmentByID(id);
    if (!existing) throw new NotFoundException(`Appointment ${id} not found`);

    const wasCompleted = existing.Status?.toLowerCase() === 'completed';
    const newStatus = data.Status ? data.Status.toLowerCase() : null;

    await this.appointmentRepository.updateAppointmentByID(id, data);

    const updated = await this.appointmentRepository.getAppointmentByID(id);
    if (!updated) throw new NotFoundException(`Appointment ${id} not found after update`);

    // Automatically create income if status changed to completed
    if (!wasCompleted && newStatus === 'completed') {
      const service = await this.serviceRepository.getServiceByID(updated.ServiceID);
      if (service && service.Price != null) {
        const existingIncome = await this.incomeRepository.getIncomeByAppointmentID(id);
        if (!existingIncome || existingIncome.length === 0) {
          await this.incomeRepository.createIncome({
            AppointmentID: id,
            Price: service.Price,
            Date: new Date().toISOString(),
          });
        }
      }
    }

    return AppointmentDTO.fromEntity(updated);
  }

  // =====================
  // DELETE by ID
  // =====================
  async deleteAppointmentByID(id: number): Promise<boolean> {
    await this.appointmentRepository.deleteAppointmentByID(id);
    return true;
  }
}
