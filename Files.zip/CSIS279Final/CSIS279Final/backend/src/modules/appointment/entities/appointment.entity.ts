import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('appointments')
export class Appointment {
  @PrimaryGeneratedColumn()
  AppointmentID: number;

  @Column()
  Name: string;

  @Column()
  ServiceID: number;

  @Column()
  Status: string;

  @Column('timestamp', { nullable: true })
ScheduledTime: Date | null;


  constructor(
    AppointmentID?: number,
    Name?: string,
    ServiceID?: number,
    Status?: string,
    ScheduledTime?: Date,
  ) {
    if (AppointmentID) this.AppointmentID = AppointmentID;
    if (Name) this.Name = Name;
    if (ServiceID) this.ServiceID = ServiceID;
    if (Status) this.Status = Status;
    if (ScheduledTime) this.ScheduledTime = ScheduledTime;
  }

  static fromRow(row: any): Appointment | null {
    if (!row) return null;
    return new Appointment(
      row.AppointmentID,
      row.Name,
      row.ServiceID,
      row.Status,
      row.ScheduledTime,
    );
  }
}
