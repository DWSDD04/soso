// src/modules/appointment/appointment.module.ts
import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { Appointment } from './entities/appointment.entity';
import { AppointmentRepository } from './repositories/appointment.repository';
import { AppointmentService } from './appointment.service';
import { AppointmentResolver } from './appointment.resolver';

// modules that AppointmentService depends on
import { ServiceModule } from '../service/service.module';
import { IncomeModule } from '../income/income.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Appointment]),
    forwardRef(() => ServiceModule),
    forwardRef(() => IncomeModule), // for creating income when appointment completed
  ],
  providers: [AppointmentService, AppointmentRepository, AppointmentResolver],
  exports: [AppointmentService, AppointmentRepository],
})
export class AppointmentModule {}
