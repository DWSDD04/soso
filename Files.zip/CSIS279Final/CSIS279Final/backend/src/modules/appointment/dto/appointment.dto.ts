import { ObjectType, Field, Int, GraphQLISODateTime } from '@nestjs/graphql';
import { Appointment } from '../entities/appointment.entity';

@ObjectType()
export class AppointmentDTO {
  @Field(() => Int, { nullable: true })
  AppointmentID?: number;

  @Field({ nullable: true })
  Name?: string;

  @Field(() => Int, { nullable: true })
  ServiceID?: number;

  @Field({ nullable: true })
  Status?: string;

  // use GraphQLISODateTime scalar and expose a Date (or null)
  @Field(() => GraphQLISODateTime, { nullable: true })
  ScheduledTime?: Date | null;

  constructor(partial: Partial<AppointmentDTO>) {
    Object.assign(this, partial);
  }

  private static safeToDate(value: any): Date | null {
    if (value === null || value === undefined || value === '') return null;
    if (value instanceof Date) {
      return isNaN(value.getTime()) ? null : value;
    }
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  static fromEntity(appointment: Appointment | null): AppointmentDTO {
    if (!appointment) throw new Error('Appointment is null');

    return new AppointmentDTO({
      AppointmentID: appointment.AppointmentID ?? undefined,
      Name: appointment.Name ?? null,
      ServiceID: appointment.ServiceID ?? undefined,
      Status: appointment.Status ?? null,
      // safe conversion — return a Date or null (GraphQL scalar will serialize it)
      ScheduledTime: AppointmentDTO.safeToDate((appointment as any).ScheduledTime),
    });
  }
}
