import { InputType, Field, Int, PartialType, GraphQLISODateTime } from '@nestjs/graphql';
import { CreateAppointmentDTO } from './create-appointment.dto';
import { IsNumber, IsOptional, IsDate } from 'class-validator';
import { Type } from 'class-transformer';

@InputType()
export class UpdateAppointmentDTO extends PartialType(CreateAppointmentDTO) {
  @Field(() => Int)
  @IsNumber()
  AppointmentID: number;

  // MATCH the type in CreateAppointmentDTO → Date
  @Field(() => GraphQLISODateTime, { nullable: true })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  ScheduledTime?: Date;
}
