import { InputType, Field, Int, GraphQLISODateTime } from '@nestjs/graphql';
import { IsString, IsNumber, IsDate } from 'class-validator';
import { Type } from 'class-transformer';

@InputType()
export class CreateAppointmentDTO {
  @Field()
  @IsString()
  Name: string;

  @Field(() => Int)
  @IsNumber()
  ServiceID: number;

  @Field()
  @IsString()
  Status: string;

  @Field(() => GraphQLISODateTime)
  @Type(() => Date)
  @IsDate()
  ScheduledTime: Date;
}
