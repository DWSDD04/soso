import { Injectable } from '@nestjs/common';
import { Repository, DataSource } from 'typeorm';
import { Appointment } from '../entities/appointment.entity';
import { AppointmentDTO } from '../dto/appointment.dto';
import { CreateAppointmentDTO } from '../dto/create-appointment.dto';
import { UpdateAppointmentDTO } from '../dto/update-appointment.dto';

@Injectable()
export class AppointmentRepository {
  private readonly repo: Repository<Appointment>;

  constructor(private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Appointment);
  }

  // ===============================
  // CREATE
  // Accept a CreateAppointmentDTO (not AppointmentDTO)
  // Convert ScheduledTime (string) -> Date before creating the entity
  // ===============================
  async createAppointment(dto: CreateAppointmentDTO): Promise<Appointment> {
    const entity = this.repo.create({
      Name: dto.Name,
      ServiceID: dto.ServiceID,
      Status: dto.Status,
      // only convert if provided and valid-ish (let DB / TypeORM handle final validation)
      ScheduledTime: dto.ScheduledTime ? new Date(dto.ScheduledTime) : undefined,
    } as Partial<Appointment>);

    return this.repo.save(entity);
  }

  // ===============================
  // GET by ID
  // ===============================
  async getAppointmentByID(AppointmentID: number): Promise<Appointment | null> {
    return this.repo.findOneBy({ AppointmentID });
  }

  // ===============================
  // GET all
  // ===============================
  async getAllAppointments(): Promise<Appointment[]> {
    return this.repo.find();
  }

  // ===============================
  // GET by ServiceID
  // ===============================
  async getAppointmentsByService(ServiceID: number): Promise<Appointment[]> {
    return this.repo.findBy({ ServiceID });
  }

  // ===============================
  // GET by Status
  // ===============================
  async getAppointmentsByStatus(Status: string): Promise<Appointment[]> {
    return this.repo.findBy({ Status });
  }

  // ===============================
  // GET upcoming appointments
  // Use Date object for param (avoid toISOString issues)
  // ===============================
  async getUpcomingAppointments(): Promise<Appointment[]> {
    return this.repo
      .createQueryBuilder('appointment')
      .where('appointment.ScheduledTime >= :now', { now: new Date() })
      .andWhere('appointment.Status != :completed', { completed: 'Completed' })
      .orderBy('appointment.ScheduledTime', 'ASC')
      .getMany();
  }

  // ===============================
  // GET by Date Range
  // Parse start/end into Dates before passing to query
  // ===============================
  async getAppointmentsByDateRange(startDate: string, endDate: string): Promise<Appointment[]> {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return this.repo
      .createQueryBuilder('appointment')
      .where('appointment.ScheduledTime BETWEEN :start AND :end', { start, end })
      .orderBy('appointment.ScheduledTime', 'ASC')
      .getMany();
  }

  // ===============================
  // UPDATE by AppointmentID
  // Accept UpdateAppointmentDTO (not AppointmentDTO) and convert ScheduledTime to Date if present
  // ===============================
  async updateAppointmentByID(
  AppointmentID: number,
  updateData: Partial<UpdateAppointmentDTO>,
): Promise<void> {
  const payload: Partial<Appointment> = {};

  if (updateData.Name !== undefined) payload.Name = updateData.Name;
  if (updateData.ServiceID !== undefined) payload.ServiceID = updateData.ServiceID;
  if (updateData.Status !== undefined) payload.Status = updateData.Status;

  // ScheduledTime logic (NEW FIXED VERSION)
  if (updateData.ScheduledTime !== undefined) {
    // If the client explicitly sends null → clear the date
    if (updateData.ScheduledTime === null) {
      payload.ScheduledTime = null;
    } else {
      // Otherwise: it is already a Date object
      payload.ScheduledTime = updateData.ScheduledTime;
    }
  }

  await this.repo.update({ AppointmentID }, payload);
}


  // ===============================
  // DELETE by AppointmentID
  // ===============================
  async deleteAppointmentByID(AppointmentID: number): Promise<void> {
    await this.repo.delete({ AppointmentID });
  }

  // ===============================
  // COUNT
  // ===============================
  async countAppointments(): Promise<number> {
    return this.repo.count();
  }
}
