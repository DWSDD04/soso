import { Injectable, NotFoundException } from '@nestjs/common';
import { ServiceRepository } from './repositories/service.repository';
import { ServiceDTO } from './dto/service.dto';

@Injectable()
export class ServiceService {
  constructor(private readonly serviceRepository: ServiceRepository) {}

  // =====================
  // LIST ALL SERVICES
  // =====================
  async listServices(): Promise<ServiceDTO[]> {
    const services = await this.serviceRepository.getServices();
    return services.map(ServiceDTO.fromEntity);
  }

  // =====================
  // GET SERVICE BY ID
  // =====================
  async getServiceByID(ServiceID: number): Promise<ServiceDTO | null> {
    const service = await this.serviceRepository.getServiceByID(ServiceID);
    return service ? ServiceDTO.fromEntity(service) : null;
  }

  // =====================
  // GET SERVICES BY TYPE
  // =====================
  async getServicesByType(Type: string): Promise<ServiceDTO[]> {
    const services = await this.serviceRepository.getServiceByType(Type);
    return services.map(ServiceDTO.fromEntity);
  }

  // =====================
  // GET SERVICES BY NAME
  // =====================
  async getServicesByName(Name: string): Promise<ServiceDTO[]> {
    const services = await this.serviceRepository.getServiceByName(Name);
    return services.map(ServiceDTO.fromEntity);
  }

  // =====================
  // GET AVAILABLE SERVICES
  // =====================
  async getAvailableServices(Available = true): Promise<ServiceDTO[]> {
    const services = await this.serviceRepository.getAvailableServices(Available);
    return services.map(ServiceDTO.fromEntity);
  }

  // =====================
  // CREATE SERVICE
  // =====================
  async createService(data: ServiceDTO): Promise<ServiceDTO> {
    const created = await this.serviceRepository.createService(data);
    return ServiceDTO.fromEntity(created);
  }

  // =====================
  // UPDATE SERVICE BY ID
  // =====================
  async updateServiceByID(ServiceID: number, data: Partial<ServiceDTO>): Promise<ServiceDTO> {
    await this.serviceRepository.updateServiceByID(ServiceID, data);
    const updated = await this.serviceRepository.getServiceByID(ServiceID);
    if (!updated) throw new NotFoundException(`Service with ID ${ServiceID} not found`);
    return ServiceDTO.fromEntity(updated);
  }

  // =====================
  // UPDATE SERVICE BY NAME
  // =====================
  async updateServiceByName(Name: string, data: Partial<ServiceDTO>): Promise<ServiceDTO[]> {
    await this.serviceRepository.updateServiceByName(Name, data);
    const updatedServices = await this.serviceRepository.getServiceByName(Name);
    if (!updatedServices || updatedServices.length === 0) {
      throw new NotFoundException(`Service with Name "${Name}" not found`);
    }
    return updatedServices.map(ServiceDTO.fromEntity);
  }

  // =====================
  // UPDATE SERVICE BY TYPE
  // =====================
  async updateServiceByType(Type: string, data: Partial<ServiceDTO>): Promise<ServiceDTO[]> {
    await this.serviceRepository.updateServiceByType(Type, data);
    const updatedServices = await this.serviceRepository.getServiceByType(Type);
    if (!updatedServices || updatedServices.length === 0) {
      throw new NotFoundException(`No services found for Type "${Type}"`);
    }
    return updatedServices.map(ServiceDTO.fromEntity);
  }

  // =====================
  // DELETE SERVICE BY ID
  // =====================
  async deleteServiceByID(ServiceID: number): Promise<void> {
    await this.serviceRepository.deleteServiceByID(ServiceID);
  }

  // =====================
  // DELETE SERVICE BY NAME
  // =====================
  async deleteServiceByName(Name: string): Promise<void> {
    await this.serviceRepository.deleteServiceByName(Name);
  }

  // =====================
  // DELETE SERVICE BY TYPE
  // =====================
  async deleteServiceByType(Type: string): Promise<void> {
    await this.serviceRepository.deleteServiceByType(Type);
  }
}
