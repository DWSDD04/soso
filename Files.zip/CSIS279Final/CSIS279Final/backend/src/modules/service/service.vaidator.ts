import { IsString, IsNumber, IsBoolean, IsOptional, Min } from 'class-validator';
import { Type } from 'class-transformer';

// =====================
// CREATE Service DTO
// =====================
export class CreateServiceDTO {
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  ServiceID: number;

  @IsString()
  Type: string;

  @IsString()
  Name: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsNumber()
  @Min(0)
  @Type(() => Number)
  Price: number;

  @IsNumber()
  @Min(1)
  @Type(() => Number)
  Duration: number;

  @IsBoolean()
  @Type(() => Boolean)
  Available: boolean;
}

// =====================
// UPDATE Service DTO
// =====================
export class UpdateServiceDTO {
  @IsOptional()
  @IsString()
  Type?: string;

  @IsOptional()
  @IsString()
  Name?: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  Price?: number;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  Duration?: number;

  @IsOptional()
  @IsBoolean()
  @Type(() => Boolean)
  Available?: boolean;
}

// =====================
// PARAM DTOs
// =====================
export class ServiceIDParam {
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  ServiceID: number;
}

export class NameParam {
  @IsString()
  Name: string;
}

export class TypeParam {
  @IsString()
  Type: string;
}

export class AvailableParam {
  @IsBoolean()
  @Type(() => Boolean)
  Available: boolean;
}
