import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  Query,
  NotFoundException,
  HttpCode,
} from '@nestjs/common';

import { ServiceService } from './service.service';

import { CreateServiceDTO } from './dto/create-service.dto';
import { UpdateServiceDTO } from './dto/update-service.dto';
import { ServiceDTO } from './dto/service.dto';

import {
  ServiceIDParam,
  NameParam,
  TypeParam,
  AvailableParam,
} from './dto/params.dto';

@Controller('services')
export class ServiceController {
  constructor(private readonly serviceService: ServiceService) {}

  // ===============================
  // GET ALL SERVICES
  // ===============================
  @Get()
  async list(): Promise<ServiceDTO[]> {
    return this.serviceService.listServices();
  }

  // ===============================
  // GET BY ID
  // ===============================
  @Get(':ServiceID')
  async get(@Param() params: ServiceIDParam): Promise<ServiceDTO> {
    const service = await this.serviceService.getServiceByID(params.ServiceID);
    if (!service) {
      throw new NotFoundException(`Service with ID ${params.ServiceID} not found`);
    }
    return service;
  }

  // ===============================
  // CREATE SERVICE
  // ===============================
  @Post()
  async create(@Body() data: CreateServiceDTO): Promise<ServiceDTO> {
    return this.serviceService.createService(data);
  }

  // ===============================
  // UPDATE BY ID
  // ===============================
  @Put(':ServiceID')
  async updateByID(
    @Param() params: ServiceIDParam,
    @Body() data: UpdateServiceDTO,
  ): Promise<ServiceDTO> {
    const updated = await this.serviceService.updateServiceByID(params.ServiceID, data);
    if (!updated) {
      throw new NotFoundException(`Service with ID ${params.ServiceID} not found`);
    }
    return updated;
  }

  // ===============================
  // UPDATE BY NAME
  // ===============================
  @Put('name/:Name')
  async updateByName(
    @Param() params: NameParam,
    @Body() data: UpdateServiceDTO,
  ): Promise<ServiceDTO[]> {
    const updated = await this.serviceService.updateServiceByName(params.Name, data);
    if (!updated || updated.length === 0) {
      throw new NotFoundException(`No services found with Name "${params.Name}"`);
    }
    return updated;
  }

  // ===============================
  // UPDATE BY TYPE
  // ===============================
  @Put('type/:Type')
  async updateByType(
    @Param() params: TypeParam,
    @Body() data: UpdateServiceDTO,
  ): Promise<ServiceDTO[]> {
    const updated = await this.serviceService.updateServiceByType(params.Type, data);
    if (!updated || updated.length === 0) {
      throw new NotFoundException(`No services found for Type "${params.Type}"`);
    }
    return updated;
  }

  // ===============================
  // DELETE BY ID
  // ===============================
  @Delete(':ServiceID')
  @HttpCode(204)
  async deleteByID(@Param() params: ServiceIDParam): Promise<void> {
    await this.serviceService.deleteServiceByID(params.ServiceID);
  }

  // ===============================
  // DELETE BY NAME
  // ===============================
  @Delete('name/:Name')
  @HttpCode(204)
  async deleteByName(@Param() params: NameParam): Promise<void> {
    await this.serviceService.deleteServiceByName(params.Name);
  }

  // ===============================
  // DELETE BY TYPE
  // ===============================
  @Delete('type/:Type')
  @HttpCode(204)
  async deleteByType(@Param() params: TypeParam): Promise<void> {
    await this.serviceService.deleteServiceByType(params.Type);
  }

  // ===============================
  // GET AVAILABLE SERVICES
  // ===============================
  @Get('available/:Available')
  async available(@Param() params: AvailableParam): Promise<ServiceDTO[]> {
    return this.serviceService.getAvailableServices(params.Available);
  }

  // ===============================
  // SEARCH BY NAME
  // ===============================
  @Get('search')
  async search(@Query('q') query: string): Promise<ServiceDTO[]> {
    if (!query) {
      throw new NotFoundException('Search query "q" is required');
    }
    return this.serviceService.getServicesByName(query);
  }

  // ===============================
// GET SERVICES BY TYPE
// ===============================
@Get('type/:Type')
async getByType(@Param() params: TypeParam): Promise<ServiceDTO[]> {
  const services = await this.serviceService.getServicesByType(params.Type);
  if (!services || services.length === 0) {
    throw new NotFoundException(`No services found for Type "${params.Type}"`);
  }
  return services;
}

}
