import { Injectable } from '@nestjs/common';
import { Repository, DataSource } from 'typeorm';
import { Service } from '../entities/service.entity';
import { ServiceDTO } from '../dto/service.dto';

@Injectable()
export class ServiceRepository {
  private readonly repo: Repository<Service>;

  constructor(private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Service);
  }

  // =====================
  // CREATE SERVICE
  // =====================
  async createService(serviceDto: ServiceDTO): Promise<Service> {
    const service = this.repo.create(serviceDto); // DTO → Entity
    return this.repo.save(service);
  }

  // =====================
  // GET SERVICE BY ID
  // =====================
  async getServiceByID(ServiceID: number): Promise<Service | null> {
    return this.repo.findOneBy({ ServiceID });
  }

  // =====================
  // GET ALL SERVICES
  // =====================
  async getServices(): Promise<Service[]> {
    return this.repo.find();
  }

  // =====================
  // GET SERVICES BY TYPE
  // =====================
  async getServiceByType(Type: string): Promise<Service[]> {
    return this.repo.findBy({ Type });
  }

  // =====================
  // GET SERVICES BY NAME
  // =====================
  async getServiceByName(Name: string): Promise<Service[]> {
    return this.repo.findBy({ Name });
  }

  // =====================
  // GET AVAILABLE SERVICES
  // =====================
  async getAvailableServices(Available: boolean): Promise<Service[]> {
    return this.repo.findBy({ Available });
  }

  // =====================
  // UPDATE SERVICE BY ID
  // =====================
  async updateServiceByID(ServiceID: number, updateData: Partial<ServiceDTO>): Promise<void> {
    await this.repo.update({ ServiceID }, updateData);
  }

  // =====================
  // UPDATE SERVICE BY NAME
  // =====================
  async updateServiceByName(Name: string, updateData: Partial<ServiceDTO>): Promise<void> {
    await this.repo.update({ Name }, updateData);
  }

  // =====================
  // UPDATE SERVICE BY TYPE
  // =====================
  async updateServiceByType(Type: string, updateData: Partial<ServiceDTO>): Promise<void> {
    await this.repo.update({ Type }, updateData);
  }

  // =====================
  // DELETE SERVICE BY ID
  // =====================
  async deleteServiceByID(ServiceID: number): Promise<void> {
    await this.repo.delete({ ServiceID });
  }

  // =====================
  // DELETE SERVICE BY NAME
  // =====================
  async deleteServiceByName(Name: string): Promise<void> {
    await this.repo.delete({ Name });
  }

  // =====================
  // DELETE SERVICE BY TYPE
  // =====================
  async deleteServiceByType(Type: string): Promise<void> {
    await this.repo.delete({ Type });
  }
}
