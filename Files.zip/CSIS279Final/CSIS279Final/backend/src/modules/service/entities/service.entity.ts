import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('services') // table name in database
export class Service {
  @PrimaryGeneratedColumn()
  ServiceID: number;

  @Column()
  Type: string;

  @Column()
  Name: string;

  @Column({ nullable: true })
  Description: string;

  @Column('decimal', { precision: 10, scale: 2 })
  Price: number;

  @Column('int')
  Duration: number; // duration in minutes

  @Column('boolean', { default: true })
  Available: boolean;

  constructor(
    ServiceID?: number,
    Type?: string,
    Name?: string,
    Description?: string,
    Price?: number,
    Duration?: number,
    Available?: boolean,
  ) {
    if (ServiceID) this.ServiceID = ServiceID;
    if (Type) this.Type = Type;
    if (Name) this.Name = Name;
    if (Description) this.Description = Description;
    if (Price) this.Price = Price;
    if (Duration) this.Duration = Duration;
    if (Available !== undefined) this.Available = Available;
  }

  static fromRow(row: any): Service | null {
    if (!row) return null;
    return new Service(
      row.ServiceID,
      row.Type,
      row.Name,
      row.Description,
      row.Price,
      row.Duration,
      row.Available,
    );
  }
}
