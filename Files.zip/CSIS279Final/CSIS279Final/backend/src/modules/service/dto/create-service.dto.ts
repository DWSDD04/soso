import { IsString, IsNumber, IsBoolean, IsOptional } from 'class-validator';

export class CreateServiceDTO {
  @IsString()
  Type: string;

  @IsString()
  Name: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsNumber()
  Price: number;

  @IsNumber()
  Duration: number;

  @IsBoolean()
  Available: boolean;
}
