import { IsString, IsNumberString, IsBoolean } from 'class-validator';

// ===============================
// PARAM: ServiceID
// ===============================
export class ServiceIDParam {
  @IsNumberString()
  ServiceID: number;
}

// ===============================
// PARAM: Name
// ===============================
export class NameParam {
  @IsString()
  Name: string;
}

// ===============================
// PARAM: Type
// ===============================
export class TypeParam {
  @IsString()
  Type: string;
}

// ===============================
// PARAM: Available
// ===============================
export class AvailableParam {
  @IsBoolean()
  Available: boolean;
}
