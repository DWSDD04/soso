import { IsString, IsNumber, IsBoolean, IsOptional } from 'class-validator';
import { Service } from '../entities/service.entity';

export class ServiceDTO {
  @IsOptional()
  @IsNumber()
  ServiceID?: number;

  @IsString()
  Type: string;

  @IsString()
  Name: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsNumber()
  Price: number;

  @IsNumber()
  Duration: number;

  @IsBoolean()
  Available: boolean;

  constructor(partial: Partial<ServiceDTO>) {
    Object.assign(this, partial);
  }

  // Converts a DB Service entity into a DTO
  static fromEntity(service: Service | null): ServiceDTO {
    if (!service) throw new Error('Service is null');
    return new ServiceDTO({
      ServiceID: service.ServiceID,
      Type: service.Type,
      Name: service.Name,
      Description: service.Description,
      Price: service.Price,
      Duration: service.Duration,
      Available: service.Available,
    });
  }
}
