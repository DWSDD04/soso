import { IsNumberString } from 'class-validator';

// ===============================
// PARAM: NotificationID
// ===============================
export class NotificationIDParam {
  @IsNumberString()
  NotificationID: number;
}

// ===============================
// PARAM: AppointmentID
// ===============================
export class AppointmentIDParam {
  @IsNumberString()
  AppointmentID: number;
}
