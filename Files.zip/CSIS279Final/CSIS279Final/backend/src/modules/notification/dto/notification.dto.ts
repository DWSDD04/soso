import { ObjectType, Field, Int } from '@nestjs/graphql';
import { IsNumber, IsOptional, IsString } from 'class-validator';
import moment from 'moment';

@ObjectType()
export class NotificationDTO {
  @Field(() => Int, { nullable: true })
  @IsOptional()
  @IsNumber()
  NotificationID?: number;

  @Field(() => Int)
  @IsNumber()
  AppointmentID: number;

  @Field()
  @IsString()
  message: string;

  @Field()
  @IsString()
  timestamp: string;

  @Field({ nullable: true })
  @IsOptional()
  read?: boolean;

  constructor(partial: Partial<NotificationDTO>) {
    Object.assign(this, partial);
    if (partial?.timestamp) {
      this.timestamp = moment(partial.timestamp).format("YYYY-MM-DD HH:mm:ss");
    }
  }

  static fromEntity(notification: any): NotificationDTO {
    return new NotificationDTO({
      NotificationID: notification.NotificationID,
      AppointmentID: notification.AppointmentID,
      message: notification.message,
      timestamp: notification.timestamp,
      read: notification.read,
    });
  }
}
