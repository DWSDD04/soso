import { InputType, Field, Int } from '@nestjs/graphql';
import { IsNumber, IsOptional, IsString, IsDateString } from 'class-validator';

@InputType()
export class UpdateNotificationDTO {
  @Field(() => Int)
  @IsNumber()
  NotificationID: number;

  @Field(() => Int, { nullable: true })
  @IsOptional()
  @IsNumber()
  AppointmentID?: number;

  @Field({ nullable: true })
  @IsOptional()
  @IsString()
  message?: string;

  @Field({ nullable: true })
  @IsOptional()
  @IsDateString()
  timestamp?: string;
}
