import { InputType, Field, Int } from '@nestjs/graphql';
import { IsNumber, IsString, IsOptional, IsDateString } from 'class-validator';

@InputType()
export class CreateNotificationDTO {
  @Field(() => Int)               
  @IsNumber()                    
  AppointmentID: number;

  @Field()                        
  @IsString()                     
  message: string;

  @Field({ nullable: true })      
  @IsOptional()
  @IsDateString()                
  timestamp?: string;
}
