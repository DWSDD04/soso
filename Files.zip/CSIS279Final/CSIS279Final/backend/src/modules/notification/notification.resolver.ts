import { Resolver, Query, Mutation, Args, Int } from '@nestjs/graphql';
import { NotFoundException } from '@nestjs/common';

import { NotificationService } from './notifcation.service';
import { NotificationDTO } from './dto/notification.dto';
import { CreateNotificationDTO } from './dto/create-notification.dto';
import { UpdateNotificationDTO } from './dto/update-notification.dto';

@Resolver(() => NotificationDTO)
export class NotificationResolver {
  constructor(private readonly notificationService: NotificationService) {}

  // LIST
  @Query(() => [NotificationDTO], { name: 'notifications' })
  async listNotifications(): Promise<NotificationDTO[]> {
    return this.notificationService.listNotifications();
  }

  // GET BY ID
  @Query(() => NotificationDTO, { name: 'notification', nullable: true })
  async getNotificationByID(
    @Args('id', { type: () => Int }) id: number,
  ): Promise<NotificationDTO | null> {
    const notification = await this.notificationService.getNotificationByID(id);
    if (!notification) {
      throw new NotFoundException(`Notification with ID ${id} not found`);
    }
    return notification;
  }

  // GET BY APPOINTMENT ID
  @Query(() => [NotificationDTO], { name: 'notificationsByAppointment', nullable: 'itemsAndList' })
  async getNotificationsByAppointmentID(
    @Args('appointmentID', { type: () => Int }) appointmentID: number,
  ): Promise<NotificationDTO[]> {
    return this.notificationService.getNotificationsByAppointmentID(appointmentID);
  }

  // GET BY DATE RANGE
  @Query(() => [NotificationDTO], { name: 'notificationsByDateRange', nullable: 'itemsAndList' })
  async getNotificationsByDateRange(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
  ): Promise<NotificationDTO[]> {
    return this.notificationService.getNotificationsByDateRange(startDate, endDate);
  }

  // COUNT
  @Query(() => Int, { name: 'countNotifications' })
  async countNotifications(): Promise<number> {
    return this.notificationService.countNotifications();
  }

  // CREATE
  @Mutation(() => NotificationDTO, { name: 'createNotification' })
  async createNotification(
    @Args('data') data: CreateNotificationDTO,
  ): Promise<NotificationDTO> {
    return this.notificationService.createNotification(data);
  }

  // UPDATE BY ID
  @Mutation(() => NotificationDTO, { name: 'updateNotificationByID' })
  async updateNotificationByID(
    @Args('data') data: UpdateNotificationDTO,
  ): Promise<NotificationDTO> {
    const updated = await this.notificationService.updateNotificationByID(data);
    if (!updated) {
      throw new NotFoundException(`Notification with ID ${(data as any).NotificationID} not found`);
    }
    return updated;
  }

  // UPDATE BY APPOINTMENT ID
  @Mutation(() => Boolean, { name: 'updateNotificationsByAppointmentID' })
  async updateNotificationsByAppointmentID(
    @Args('appointmentID', { type: () => Int }) appointmentID: number,
    @Args('data') data: CreateNotificationDTO,
  ): Promise<boolean> {
    await this.notificationService.updateNotificationsByAppointmentID(appointmentID, data);
    return true;
  }

  // UPDATE BY DATE RANGE
  @Mutation(() => Boolean, { name: 'updateNotificationsByDateRange' })
  async updateNotificationsByDateRange(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
    @Args('data') data: CreateNotificationDTO,
  ): Promise<boolean> {
    await this.notificationService.updateNotificationsByDateRange(startDate, endDate, data);
    return true;
  }

  // DELETE BY ID
  @Mutation(() => Boolean, { name: 'deleteNotificationByID' })
  async deleteNotificationByID(
    @Args('id', { type: () => Int }) id: number,
  ): Promise<boolean> {
    const ok = await this.notificationService.deleteNotificationByID(id);
    if (!ok) throw new NotFoundException(`Notification with ID ${id} not found`);
    return true;
  }

  // DELETE BY APPOINTMENT ID
  @Mutation(() => Boolean, { name: 'deleteNotificationsByAppointmentID' })
  async deleteNotificationsByAppointmentID(
    @Args('appointmentID', { type: () => Int }) appointmentID: number,
  ): Promise<boolean> {
    const ok = await this.notificationService.deleteNotificationsByAppointmentID(appointmentID);
    if (!ok) throw new NotFoundException(`No notifications found for appointment ${appointmentID}`);
    return true;
  }

  // DELETE BY DATE RANGE
  @Mutation(() => Boolean, { name: 'deleteNotificationsByDateRange' })
  async deleteNotificationsByDateRange(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
  ): Promise<boolean> {
    await this.notificationService.deleteNotificationsByDateRange(startDate, endDate);
    return true;
  }
}
