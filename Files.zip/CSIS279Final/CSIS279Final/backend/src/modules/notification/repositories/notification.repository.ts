import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between } from 'typeorm';
import moment from 'moment';

import { Notification } from '../entities/notification.entity';
import { NotificationDTO } from '../dto/notification.dto';
import { CreateNotificationDTO } from '../dto/create-notification.dto';

@Injectable()
export class NotificationRepository {
  constructor(
    @InjectRepository(Notification)
    private readonly repo: Repository<Notification>,
  ) {}

  // Get all notifications ordered by timestamp desc
  async getNotifications(): Promise<NotificationDTO[]> {
    const rows = await this.repo.find({ order: { timestamp: 'DESC' } });
    return rows.map(r => NotificationDTO.fromEntity(r));
  }

  // Get by ID
  async getNotificationByID(id: number): Promise<NotificationDTO | null> {
    const row = await this.repo.findOne({ where: { NotificationID: id } });
    if (!row) return null;
    return NotificationDTO.fromEntity(row);
  }

  // Get by AppointmentID
  async getNotificationsByAppointmentID(appointmentID: number): Promise<NotificationDTO[]> {
    const rows = await this.repo.find({ where: { AppointmentID: appointmentID }, order: { timestamp: 'DESC' } });
    return rows.map(r => NotificationDTO.fromEntity(r));
  }

  // Get between dates (accepts strings or Date)
  async getNotificationsByDateRange(startDate: string, endDate: string): Promise<NotificationDTO[]> {
    // Ensure formatting is compatible with stored timestamp
    const start = moment(startDate).format('YYYY-MM-DD HH:mm:ss');
    const end = moment(endDate).format('YYYY-MM-DD HH:mm:ss');
    const rows = await this.repo.find({
      where: { timestamp: Between(start, end) },
      order: { timestamp: 'DESC' },
    });
    return rows.map(r => NotificationDTO.fromEntity(r));
  }

  // Create new notification
  async createNotification(data: CreateNotificationDTO | Partial<Notification>): Promise<NotificationDTO> {
    const toSave = this.repo.create({
      AppointmentID: data.AppointmentID,
      message: data.message,
      // if timestamp provided use formatted; otherwise use now
      timestamp: data['timestamp']
        ? moment((data as any).timestamp).format('YYYY-MM-DD HH:mm:ss')
        : moment().format('YYYY-MM-DD HH:mm:ss'),
    } as Notification);

    const saved = await this.repo.save(toSave);
    return NotificationDTO.fromEntity(saved);
  }

  // Update by ID (partial)
  async updateNotificationByID(id: number, updateData: Partial<CreateNotificationDTO>): Promise<number> {
    if (updateData.timestamp) {
      updateData.timestamp = moment(updateData.timestamp).format('YYYY-MM-DD HH:mm:ss');
    }
    const res = await this.repo.update({ NotificationID: id }, updateData as Partial<Notification>);
    return res.affected ?? 0;
  }

  // Update by AppointmentID
  async updateNotificationsByAppointmentID(appointmentID: number, updateData: Partial<CreateNotificationDTO>): Promise<number> {
    if (updateData.timestamp) {
      updateData.timestamp = moment(updateData.timestamp).format('YYYY-MM-DD HH:mm:ss');
    }
    const res = await this.repo.update({ AppointmentID: appointmentID }, updateData as Partial<Notification>);
    return res.affected ?? 0;
  }

  // Update by date range
  async updateNotificationsByDateRange(startDate: string, endDate: string, updateData: Partial<CreateNotificationDTO>): Promise<number> {
    if (updateData.timestamp) {
      updateData.timestamp = moment(updateData.timestamp).format('YYYY-MM-DD HH:mm:ss');
    }
    const start = moment(startDate).format('YYYY-MM-DD HH:mm:ss');
    const end = moment(endDate).format('YYYY-MM-DD HH:mm:ss');

    const qb = this.repo.createQueryBuilder()
      .update(Notification)
      .set(updateData as Partial<Notification>)
      .where('timestamp BETWEEN :start AND :end', { start, end });

    const res = await qb.execute();
    return res.affected ?? 0;
  }

  // Delete by ID
  async deleteNotificationByID(id: number): Promise<number> {
    const res = await this.repo.delete({ NotificationID: id });
    return res.affected ?? 0;
  }

  // Delete by AppointmentID
  async deleteNotificationsByAppointmentID(appointmentID: number): Promise<number> {
    const res = await this.repo.delete({ AppointmentID: appointmentID });
    return res.affected ?? 0;
  }

  // Delete by date range
  async deleteNotificationsByDateRange(startDate: string, endDate: string): Promise<number> {
    const start = moment(startDate).format('YYYY-MM-DD HH:mm:ss');
    const end = moment(endDate).format('YYYY-MM-DD HH:mm:ss');
    const qb = this.repo.createQueryBuilder()
      .delete()
      .from(Notification)
      .where('timestamp BETWEEN :start AND :end', { start, end });

    const res = await qb.execute();
    return res.affected ?? 0;
  }

  // Count
  async countNotifications(): Promise<number> {
    return this.repo.count();
  }
}
