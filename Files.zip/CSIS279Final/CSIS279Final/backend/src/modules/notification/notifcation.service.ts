import { Injectable, NotFoundException } from '@nestjs/common';
import { NotificationRepository } from './repositories/notification.repository';
import { NotificationDTO } from './dto/notification.dto';
import { CreateNotificationDTO } from './dto/create-notification.dto';
import { UpdateNotificationDTO } from './dto/update-notification.dto';

@Injectable()
export class NotificationService {
  constructor(
    private readonly notificationRepository: NotificationRepository,
  ) {}

  // List all
  async listNotifications(): Promise<NotificationDTO[]> {
    return this.notificationRepository.getNotifications();
  }

  // Get by ID
  async getNotificationByID(id: number): Promise<NotificationDTO> {
    const notification = await this.notificationRepository.getNotificationByID(id);
    if (!notification) throw new NotFoundException(`Notification ${id} not found`);
    return notification;
  }

  // Get by appointment
  async getNotificationsByAppointmentID(appointmentID: number): Promise<NotificationDTO[]> {
    return this.notificationRepository.getNotificationsByAppointmentID(appointmentID);
  }

  // Get by date range
  async getNotificationsByDateRange(start: string, end: string): Promise<NotificationDTO[]> {
    return this.notificationRepository.getNotificationsByDateRange(start, end);
  }

  // Create
  async createNotification(data: CreateNotificationDTO): Promise<NotificationDTO> {
    return this.notificationRepository.createNotification(data);
  }

  // Update by ID
  async updateNotificationByID(data: UpdateNotificationDTO): Promise<NotificationDTO> {
    const { NotificationID, ...updateData } = data;
    const affected = await this.notificationRepository.updateNotificationByID(NotificationID, updateData);
    if (!affected) throw new NotFoundException(`Notification ${NotificationID} not found`);
    const updated = await this.notificationRepository.getNotificationByID(NotificationID);
    if (!updated) throw new NotFoundException(`Notification ${NotificationID} not found after update`);
    return updated;
  }

  // Update by appointment
  async updateNotificationsByAppointmentID(appointmentID: number, update: Partial<CreateNotificationDTO>): Promise<boolean> {
    await this.notificationRepository.updateNotificationsByAppointmentID(appointmentID, update);
    return true;
  }

  // Update by date range
  async updateNotificationsByDateRange(start: string, end: string, update: Partial<CreateNotificationDTO>): Promise<boolean> {
    await this.notificationRepository.updateNotificationsByDateRange(start, end, update);
    return true;
  }

  // Delete by ID
  async deleteNotificationByID(id: number): Promise<boolean> {
    const affected = await this.notificationRepository.deleteNotificationByID(id);
    if (!affected) return false;
    return true;
  }

  // Delete by appointment
  async deleteNotificationsByAppointmentID(appointmentID: number): Promise<boolean> {
    const affected = await this.notificationRepository.deleteNotificationsByAppointmentID(appointmentID);
    return affected > 0;
  }

  // Delete by date range
  async deleteNotificationsByDateRange(start: string, end: string): Promise<boolean> {
    const affected = await this.notificationRepository.deleteNotificationsByDateRange(start, end);
    return affected > 0;
  }

  // Count
  async countNotifications(): Promise<number> {
    return this.notificationRepository.countNotifications();
  }
}
