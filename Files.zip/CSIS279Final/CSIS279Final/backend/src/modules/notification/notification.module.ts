// src/modules/notification/notification.module.ts
import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { Notification } from './entities/notification.entity';
import { NotificationRepository } from './repositories/notification.repository';
import { NotificationService } from './notifcation.service';
import { NotificationResolver } from './notification.resolver';

// modules NotificationService might depend on
import { AppointmentModule } from '../appointment/appointment.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Notification]),
    // forwardRef in case AppointmentModule also imports NotificationModule
    forwardRef(() => AppointmentModule),
  ],
  providers: [NotificationService, NotificationRepository, NotificationResolver],
  exports: [NotificationService, NotificationRepository],
})
export class NotificationModule {}
