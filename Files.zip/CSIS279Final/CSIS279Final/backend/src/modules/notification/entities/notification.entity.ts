import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import moment from 'moment';

@Entity('notification')
export class Notification {
  @PrimaryGeneratedColumn()
  NotificationID: number;

  @Column()
  AppointmentID: number;

  @Column()
  message: string;

  @Column()
  timestamp: string; // stored as string in DB, formatted as "YYYY-MM-DD HH:mm:ss"

  constructor(
    NotificationID?: number,
    AppointmentID?: number,
    message?: string,
    timestamp?: string | Date,
  ) {
    if (NotificationID) this.NotificationID = NotificationID;
    if (AppointmentID) this.AppointmentID = AppointmentID;
    if (message) this.message = message;
    if (timestamp) {
      this.timestamp = moment(timestamp).format("YYYY-MM-DD HH:mm:ss");
    }
  }

  static fromRow(row: any): Notification | null {
    if (!row) return null;
    return new Notification(
      row.NotificationID,
      row.AppointmentID,
      row.message,
      row.timestamp
    );
  }
}
