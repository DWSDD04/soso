// src/modules/income/income.module.ts
import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { Income } from './entities/income.entity';
import { IncomeRepository } from './repositories/income.repository';
import { IncomeService } from './income.service';
import { IncomeResolver } from './income.resolver';

// import modules that IncomeService depends on
import { AppointmentModule } from '../appointment/appointment.module';
import { ServiceModule } from '../service/service.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Income]),
    // forwardRef in case appointment/service modules also import IncomeModule
    forwardRef(() => AppointmentModule),
    forwardRef(() => ServiceModule),
  ],
  providers: [IncomeService, IncomeRepository, IncomeResolver],
  exports: [IncomeService, IncomeRepository],
})
export class IncomeModule {}
