import { Injectable } from '@nestjs/common';
import { Repository, DataSource } from 'typeorm';
import { Income } from '../entities/income.entity';
import { IncomeDTO } from '../dto/income.dto';

@Injectable()
export class IncomeRepository {
  private readonly repo: Repository<Income>;

  constructor(private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Income);
  }

  // ===============================
  // CREATE
  // ===============================
  async createIncome(incomeDto: IncomeDTO): Promise<Income> {
    const income = this.repo.create(incomeDto);
    return this.repo.save(income);
  }

  // ===============================
  // GET by ID
  // ===============================
  async getIncomeByID(IncomeID: number): Promise<Income | null> {
    return this.repo.findOneBy({ IncomeID });
  }

  // ===============================
  // GET all
  // ===============================
  async getIncomes(): Promise<Income[]> {
    return this.repo.find();
  }

  // ===============================
  // GET by AppointmentID
  // ===============================
  async getIncomeByAppointmentID(AppointmentID: number): Promise<Income[]> {
    return this.repo.findBy({ AppointmentID });
  }

  // ===============================
  // GET by Price
  // ===============================
  async getIncomeByPrice(Price: number): Promise<Income[]> {
    return this.repo.findBy({ Price });
  }

  // ===============================
  // GET by Date
  // ===============================
  async getIncomeByDate(Date: string): Promise<Income[]> {
    return this.repo.findBy({ Date });
  }

  // ===============================
  // GET by Date Range
  // ===============================
  async getIncomesByDateRange(startDate: string, endDate: string): Promise<Income[]> {
    return this.repo
      .createQueryBuilder('income')
      .where('income.Date BETWEEN :start AND :end', { start: startDate, end: endDate })
      .orderBy('income.Date', 'ASC')
      .getMany();
  }

  // ===============================
  // UPDATE by IncomeID
  // ===============================
  async updateIncomeByID(IncomeID: number, updateData: Partial<IncomeDTO>): Promise<void> {
    await this.repo.update({ IncomeID }, updateData);
  }

  // ===============================
  // UPDATE by AppointmentID
  // ===============================
  async updateIncomeByAppointmentID(AppointmentID: number, updateData: Partial<IncomeDTO>): Promise<void> {
    await this.repo.update({ AppointmentID }, updateData);
  }

  // ===============================
  // UPDATE by Date Range
  // ===============================
  async updateIncomeByDateRange(startDate: string, endDate: string, updateData: Partial<IncomeDTO>): Promise<void> {
    await this.repo
      .createQueryBuilder()
      .update(Income)
      .set(updateData)
      .where('Date BETWEEN :start AND :end', { start: startDate, end: endDate })
      .execute();
  }

  // ===============================
  // DELETE by ID
  // ===============================
  async deleteIncomeByID(IncomeID: number): Promise<void> {
    await this.repo.delete({ IncomeID });
  }

  // ===============================
  // DELETE by AppointmentID
  // ===============================
  async deleteIncomeByAppointmentID(AppointmentID: number): Promise<void> {
    await this.repo.delete({ AppointmentID });
  }

  // ===============================
  // DELETE by Date
  // ===============================
  async deleteIncomeByDate(Date: string): Promise<void> {
    await this.repo.delete({ Date });
  }

  // ===============================
  // DELETE by Date Range
  // ===============================
  async deleteIncomesByDateRange(startDate: string, endDate: string): Promise<void> {
    await this.repo
      .createQueryBuilder()
      .delete()
      .from(Income)
      .where('Date BETWEEN :start AND :end', { start: startDate, end: endDate })
      .execute();
  }

  // ===============================
  // COUNT
  // ===============================
  async countIncomes(): Promise<number> {
    return this.repo.count();
  }
}
