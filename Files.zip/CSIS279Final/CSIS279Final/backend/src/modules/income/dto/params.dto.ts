import { ArgsType, Field, Int } from '@nestjs/graphql';
import { IsNumber } from 'class-validator';

@ArgsType()
export class IncomeIDParam {
  @Field(() => Int)
  @IsNumber()
  IncomeID: number;
}

@ArgsType()
export class AppointmentIDParam {
  @Field(() => Int)
  @IsNumber()
  AppointmentID: number;
}
