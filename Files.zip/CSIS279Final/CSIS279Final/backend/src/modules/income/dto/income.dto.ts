import { ObjectType, Field, Int, Float } from '@nestjs/graphql';
import { IsNumber, IsOptional, IsString, IsDateString } from 'class-validator';
import { Income } from '../entities/income.entity';

@ObjectType()
export class IncomeDTO {
  @Field(() => Int, { nullable: true })
  @IsOptional()
  @IsNumber()
  IncomeID?: number;

  @Field(() => Int)
  @IsNumber()
  AppointmentID: number;

  @Field(() => Float)
  @IsNumber()
  Price: number;

  @Field()
  @IsDateString()
  Date: string;

  constructor(partial: Partial<IncomeDTO>) {
    Object.assign(this, partial);
  }

  static fromEntity(income: Income | null): IncomeDTO {
    if (!income) throw new Error('Income is null');

    return new IncomeDTO({
      IncomeID: income.IncomeID,
      AppointmentID: income.AppointmentID,
      Price: income.Price,
      Date: income.Date,
    });
  }

  static fromRow(row: any): IncomeDTO {
    return new IncomeDTO({
      IncomeID: row.IncomeID,
      AppointmentID: row.AppointmentID,
      Price: row.Price,
      Date: row.Date,
    });
  }
}
