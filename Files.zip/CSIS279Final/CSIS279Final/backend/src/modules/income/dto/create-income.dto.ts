import { InputType, Field, Float, Int } from '@nestjs/graphql';
import { IsNumber, IsString, IsDateString } from 'class-validator';

@InputType()
export class CreateIncomeDTO {
  @Field(() => Int)
  @IsNumber()
  AppointmentID: number;

  @Field(() => Float)
  @IsNumber()
  Price: number;

  @Field()
  @IsDateString() // validates ISO date string
  Date: string;
}
