import { InputType, Field, Float, Int, PartialType } from '@nestjs/graphql';
import { CreateIncomeDTO } from './create-income.dto';
import { IsNumber } from 'class-validator';

@InputType()
export class UpdateIncomeDTO extends PartialType(CreateIncomeDTO) {
  @Field(() => Int)
  @IsNumber()
  IncomeID: number; 
}
