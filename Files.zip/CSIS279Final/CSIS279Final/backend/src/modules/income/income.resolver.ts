// src/modules/income/income.resolver.ts
import { Resolver, Query, Mutation, Args, Int } from '@nestjs/graphql';
import { NotFoundException } from '@nestjs/common';

import { IncomeService } from './income.service';
import { IncomeDTO } from './dto/income.dto';
import { CreateIncomeDTO } from './dto//create-income.dto';
import { UpdateIncomeDTO } from './dto/update-income.dto';

@Resolver(() => IncomeDTO)
export class IncomeResolver {
  constructor(private readonly incomeService: IncomeService) {}

  // ===============================
  // GET ALL
  // ===============================
  @Query(() => [IncomeDTO], { name: 'incomes' })
  async listIncomes(): Promise<IncomeDTO[]> {
    return this.incomeService.listIncomes();
  }

  // ===============================
  // GET BY ID
  // ===============================
  @Query(() => IncomeDTO, { name: 'income', nullable: true })
  async getIncomeByID(
    @Args('id', { type: () => Int }) id: number,
  ): Promise<IncomeDTO | null> {
    const income = await this.incomeService.getIncomeByID(id);
    if (!income) {
      throw new NotFoundException(`Income with ID ${id} not found`);
    }
    return income;
  }

  // ===============================
  // GET BY APPOINTMENT ID
  // ===============================
  @Query(() => [IncomeDTO], { name: 'incomesByAppointment', nullable: 'itemsAndList' })
  async getIncomeByAppointmentID(
    @Args('appointmentID', { type: () => Int }) appointmentID: number,
  ): Promise<IncomeDTO[]> {
    return this.incomeService.getIncomeByAppointmentID(appointmentID);
  }

  // ===============================
  // GET BY DATE
  // ===============================
  @Query(() => [IncomeDTO], { name: 'incomesByDate', nullable: 'itemsAndList' })
  async getIncomeByDate(@Args('date') date: string): Promise<IncomeDTO[]> {
    return this.incomeService.getIncomeByDate(date);
  }

  // ===============================
  // GET BY DATE RANGE
  // ===============================
  @Query(() => [IncomeDTO], { name: 'incomesByDateRange', nullable: 'itemsAndList' })
  async getIncomesByDateRange(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
  ): Promise<IncomeDTO[]> {
    return this.incomeService.getIncomesByDateRange(startDate, endDate);
  }

  // ===============================
  // COUNT
  // ===============================
  @Query(() => Int, { name: 'countIncomes' })
  async countIncomes(): Promise<number> {
    return this.incomeService.countIncomes();
  }

  // ===============================
  // CREATE
  // ===============================
  @Mutation(() => IncomeDTO, { name: 'createIncome' })
  async createIncome(
    @Args('data') data: CreateIncomeDTO,
  ): Promise<IncomeDTO> {
    const created = await this.incomeService.createIncome(data);
    return created;
  }

  // ===============================
  // CREATE FROM APPOINTMENT
  // ===============================
  @Mutation(() => IncomeDTO, { name: 'createIncomeFromAppointment', nullable: true })
  async createIncomeFromAppointment(
    @Args('appointmentID', { type: () => Int }) appointmentID: number,
  ): Promise<IncomeDTO | null> {
    const income = await this.incomeService.createIncomeFromAppointment(appointmentID);
    if (!income) {
      throw new NotFoundException(`Could not create income for appointment ${appointmentID}`);
    }
    return income;
  }

  // ===============================
  // UPDATE BY ID
  // ===============================
  @Mutation(() => IncomeDTO, { name: 'updateIncomeByID' })
  async updateIncomeByID(
    @Args('data') data: UpdateIncomeDTO,
  ): Promise<IncomeDTO> {
    // UpdateIncomeInput is expected to include IncomeID and optional fields
    const updated = await this.incomeService.updateIncomeByID(data);
    if (!updated) {
      throw new NotFoundException(`Income with ID ${(data as any).IncomeID} not found`);
    }
    return updated;
  }

  // ===============================
  // UPDATE BY APPOINTMENT ID
  // (returns boolean like the controller's update endpoints)
  // ===============================
  @Mutation(() => Boolean, { name: 'updateIncomeByAppointmentID' })
  async updateIncomeByAppointmentID(
    @Args('appointmentID', { type: () => Int }) appointmentID: number,
    @Args('data') data: CreateIncomeDTO,
  ): Promise<boolean> {
    // service.updateIncomeByAppointmentID expects (appointmentID, updateData)
    await this.incomeService.updateIncomeByAppointmentID(appointmentID, data);
    return true;
  }

  // ===============================
  // UPDATE BY DATE RANGE
  // ===============================
  @Mutation(() => Boolean, { name: 'updateIncomeByDateRange' })
  async updateIncomeByDateRange(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
    @Args('data') data: CreateIncomeDTO,
  ): Promise<boolean> {
    await this.incomeService.updateIncomeByDateRange(startDate, endDate, data);
    return true;
  }

  // ===============================
  // DELETE BY ID
  // ===============================
  @Mutation(() => Boolean, { name: 'deleteIncomeByID' })
  async deleteIncomeByID(
    @Args('id', { type: () => Int }) id: number,
  ): Promise<boolean> {
    await this.incomeService.deleteIncomeByID(id);
    return true;
  }

  // ===============================
  // DELETE BY APPOINTMENT ID
  // ===============================
  @Mutation(() => Boolean, { name: 'deleteIncomeByAppointmentID' })
  async deleteIncomeByAppointmentID(
    @Args('appointmentID', { type: () => Int }) appointmentID: number,
  ): Promise<boolean> {
    await this.incomeService.deleteIncomeByAppointmentID(appointmentID);
    return true;
  }

  // ===============================
  // DELETE BY DATE
  // ===============================
  @Mutation(() => Boolean, { name: 'deleteIncomeByDate' })
  async deleteIncomeByDate(@Args('date') date: string): Promise<boolean> {
    await this.incomeService.deleteIncomeByDate(date);
    return true;
  }

  // ===============================
  // DELETE BY DATE RANGE
  // ===============================
  @Mutation(() => Boolean, { name: 'deleteIncomesByDateRange' })
  async deleteIncomesByDateRange(
    @Args('startDate') startDate: string,
    @Args('endDate') endDate: string,
  ): Promise<boolean> {
    await this.incomeService.deleteIncomesByDateRange(startDate, endDate);
    return true;
  }
}
