import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { ObjectType, Field, Int, Float } from '@nestjs/graphql';

@ObjectType() // <-- GraphQL object type
@Entity('income')
export class Income {
  @Field(() => Int)
  @PrimaryGeneratedColumn()
  IncomeID: number;

  @Field(() => Int)
  @Column()
  AppointmentID: number;

  @Field(() => Float)
  @Column('decimal', { precision: 10, scale: 2 })
  Price: number;

  @Field() // or () => Date if you store as Date
  @Column()
  Date: string;

  constructor(
    IncomeID?: number,
    AppointmentID?: number,
    Price?: number,
    Date?: string,
  ) {
    if (IncomeID) this.IncomeID = IncomeID;
    if (AppointmentID) this.AppointmentID = AppointmentID;
    if (Price) this.Price = Price;
    if (Date) this.Date = Date;
  }

  static fromRow(row: any): Income | null {
    if (!row) return null;
    return new Income(
      row.IncomeID,
      row.AppointmentID,
      row.Price,
      row.Date
    );
  }
}
