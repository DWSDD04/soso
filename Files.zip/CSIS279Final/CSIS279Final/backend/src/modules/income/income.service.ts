import { Injectable, NotFoundException } from '@nestjs/common';
import { IncomeRepository } from './repositories/income.repository';
import { AppointmentRepository } from '../appointment/repositories/appointment.repository';
import { ServiceRepository } from '../service/repositories/service.repository';
import { IncomeDTO } from './dto/income.dto';
import { CreateIncomeDTO } from './dto/create-income.dto';
import { UpdateIncomeDTO } from './dto/update-income.dto';

@Injectable()
export class IncomeService {
  constructor(
    private readonly incomeRepository: IncomeRepository,
    private readonly appointmentRepository: AppointmentRepository,
    private readonly serviceRepository: ServiceRepository,
  ) {}

  // =====================
  // GET ALL
  // =====================
  async listIncomes(): Promise<IncomeDTO[]> {
    const incomes = await this.incomeRepository.getIncomes();
    return incomes.map(i => i);
  }

  // =====================
  // GET by ID
  // =====================
  async getIncomeByID(id: number): Promise<IncomeDTO> {
    const income = await this.incomeRepository.getIncomeByID(id);
    if (!income) throw new NotFoundException(`Income ${id} not found`);
    return income;
  }

  // =====================
  // GET by AppointmentID
  // =====================
  async getIncomeByAppointmentID(AppointmentID: number): Promise<IncomeDTO[]> {
    return this.incomeRepository.getIncomeByAppointmentID(AppointmentID);
  }

  // =====================
  // GET by Price
  // =====================
  async getIncomeByPrice(price: number): Promise<IncomeDTO[]> {
    return this.incomeRepository.getIncomeByPrice(price);
  }

  // =====================
  // GET by Date
  // =====================
  async getIncomeByDate(date: string): Promise<IncomeDTO[]> {
    return this.incomeRepository.getIncomeByDate(date);
  }

  // =====================
  // GET by date range
  // =====================
  async getIncomesByDateRange(start: string, end: string): Promise<IncomeDTO[]> {
    return this.incomeRepository.getIncomesByDateRange(start, end);
  }

  // =====================
  // CREATE
  // =====================
  async createIncome(data: CreateIncomeDTO): Promise<IncomeDTO> {
    const created = await this.incomeRepository.createIncome(data);
    return created;
  }

  // =====================
  // UPDATE by ID
  // =====================
  async updateIncomeByID(data: UpdateIncomeDTO): Promise<IncomeDTO> {
    const { IncomeID, ...updateData } = data;

    await this.incomeRepository.updateIncomeByID(IncomeID, updateData);

    const updated = await this.incomeRepository.getIncomeByID(IncomeID);
    if (!updated) throw new NotFoundException(`Income ${IncomeID} not found`);

    return updated;
  }

  // =====================
  // UPDATE by AppointmentID
  // =====================
  async updateIncomeByAppointmentID(AppointmentID: number, update: Partial<IncomeDTO>): Promise<boolean> {
    await this.incomeRepository.updateIncomeByAppointmentID(AppointmentID, update);
    return true;
  }

  // =====================
  // UPDATE by Date range
  // =====================
  async updateIncomeByDateRange(start: string, end: string, update: Partial<IncomeDTO>): Promise<boolean> {
    await this.incomeRepository.updateIncomeByDateRange(start, end, update);
    return true;
  }

  // =====================
  // DELETE by ID
  // =====================
  async deleteIncomeByID(id: number): Promise<boolean> {
    await this.incomeRepository.deleteIncomeByID(id);
    return true;
  }

  // =====================
  // DELETE by AppointmentID
  // =====================
  async deleteIncomeByAppointmentID(AppointmentID: number): Promise<boolean> {
    await this.incomeRepository.deleteIncomeByAppointmentID(AppointmentID);
    return true;
  }

  // =====================
  // DELETE by date
  // =====================
  async deleteIncomeByDate(date: string): Promise<boolean> {
    await this.incomeRepository.deleteIncomeByDate(date);
    return true;
  }

  // =====================
  // DELETE by range
  // =====================
  async deleteIncomesByDateRange(start: string, end: string): Promise<boolean> {
    await this.incomeRepository.deleteIncomesByDateRange(start, end);
    return true;
  }

  // =====================
  // COUNT
  // =====================
  async countIncomes(): Promise<number> {
    return this.incomeRepository.countIncomes();
  }

  // =====================
  // Create income when appointment is finished
  // =====================
  async createIncomeFromAppointment(AppointmentID: number): Promise<IncomeDTO> {
    const appointment = await this.appointmentRepository.getAppointmentByID(AppointmentID);
    if (!appointment) throw new NotFoundException(`Appointment ${AppointmentID} not found`);

    const service = await this.serviceRepository.getServiceByID(appointment.ServiceID);
    if (!service) throw new NotFoundException(`Service ${appointment.ServiceID} not found`);

    const existing = await this.incomeRepository.getIncomeByAppointmentID(AppointmentID);
    if (existing.length > 0) return existing[0];

    const newIncome = await this.incomeRepository.createIncome({
      AppointmentID,
      Price: service.Price,
      Date: new Date().toISOString(),
    });

    return newIncome;
  }
}
