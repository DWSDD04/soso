import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('users') // Table name
export class User {
  @PrimaryGeneratedColumn()
  UserID: number;

  @Column()
  Username: string;

  @Column()
  Email: string;

  @Column()
  Password: string;

  @Column({ type: 'varchar', length: 20 })
Status: string;

  // Optional constructor
  constructor(
    UserID?: number,
    Username?: string,
    Email?: string,
    Password?: string,
    Status?: string,
  ) {
    if (UserID) this.UserID = UserID;
    if (Username) this.Username = Username;
    if (Email) this.Email = Email;
    if (Password) this.Password = Password;
    if (Status !== undefined) this.Status = Status;
  }

  // Optional static mapper (similar to your product)
  static fromRow(row: any): User | null {
    if (!row) return null;
    return new User(
      row.UserID,
      row.Username,
      row.Email,
      row.Password,
      row.Status,
    );
  }
}
