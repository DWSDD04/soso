import { IsNumberString, IsEmail, IsString, IsIn } from 'class-validator';
import { VALID_STATUSES } from './user.dto';

// ===============================
// PARAM: UserID
// ===============================
export class UserIDParam {
  @IsNumberString()
  UserID: number;
}

// ===============================
// PARAM: Email
// ===============================
export class EmailParam {
  @IsEmail()
  Email: string;
}

// ===============================
// PARAM: Status
// ===============================
export class StatusParam {
  @IsString()
  @IsIn(VALID_STATUSES)
  status: string;
}
