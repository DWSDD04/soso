import { IsString, IsNumber, IsEmail, IsOptional, IsIn, Matches } from 'class-validator';
import { User } from '../entities/user.entity';

export const VALID_STATUSES = ['Client', 'Employee', 'Admin'] as const;

export class UserDTO {
  @IsOptional()
  @IsNumber()
  UserID?: number;

  @IsString()
  Username: string;

  @IsEmail()
  Email: string;

  @IsString()
  @Matches(
    /^(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}$/,
    { message: 'Password must be at least 8 chars long and include numbers & symbols' }
  )
  Password: string;

  @IsString()
  @IsIn(VALID_STATUSES)
  Status: string;

  constructor(partial: Partial<UserDTO>) {
    Object.assign(this, partial);
  }

  // Convert entity → DTO
  static fromEntity(user: User | null): UserDTO {
    if (!user) throw new Error('User is null');
    return new UserDTO({
      UserID: user.UserID,
      Username: user.Username,
      Email: user.Email,
      Password: user.Password,
      Status: user.Status,
    });
  }
}
