import { IsString, IsEmail, IsIn, Matches } from 'class-validator';
import { VALID_STATUSES } from './user.dto';

export class CreateUserDTO {
  @IsString()
  Username: string;

  @IsEmail()
  Email: string;

  @IsString()
  @Matches(
    /^(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}$/,
    { message: 'Password must be at least 8 chars long and include numbers & symbols' }
  )
  Password: string;

  @IsString()
  @IsIn(VALID_STATUSES)
  Status: string;
}
