import { Injectable, NotFoundException } from '@nestjs/common';
import { UserRepository } from './repositories/user.repository';
import { UserDTO } from './dto/user.dto';

@Injectable()
export class UserService {
  constructor(private readonly userRepository: UserRepository) {}

  // List all users
  async listUsers(): Promise<UserDTO[]> {
    const users = await this.userRepository.getAllUsers();
    return users.map(UserDTO.fromEntity);
  }

  // Get user by ID
  async getUserByID(id: number): Promise<UserDTO | null> {
    const user = await this.userRepository.getUserByID(id);
    return user ? UserDTO.fromEntity(user) : null;
  }

  // Get user by email
  async getUserByEmail(email: string): Promise<UserDTO | null> {
    const user = await this.userRepository.getUserByEmail(email);
    return user ? UserDTO.fromEntity(user) : null;
  }

  // Get users by status ("Active", "Inactive", etc.)
  async getUsersByStatus(status: string): Promise<UserDTO[]> {
    const users = await this.userRepository.getUserByStatus(status);
    return users.map(UserDTO.fromEntity);
  }

  // Create a new user
  async createUser(data: UserDTO): Promise<UserDTO> {
    const created = await this.userRepository.createUser(data);
    return UserDTO.fromEntity(created);
  }

  // Update user by ID
  async updateUserByID(id: number, data: Partial<UserDTO>): Promise<UserDTO> {
    await this.userRepository.updateUserByID(id, data);
    const updated = await this.userRepository.getUserByID(id);

    if (!updated) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    return UserDTO.fromEntity(updated);
  }

  // Update user by Email
  async updateUserByEmail(email: string, data: Partial<UserDTO>): Promise<UserDTO> {
    await this.userRepository.updateUserByEmail(email, data);
    const updated = await this.userRepository.getUserByEmail(email);

    if (!updated) {
      throw new NotFoundException(`User with Email ${email} not found`);
    }

    return UserDTO.fromEntity(updated);
  }

  // Delete user by ID
  async deleteUserByID(id: number): Promise<boolean> {
    const existing = await this.userRepository.getUserByID(id);
    if (!existing) throw new NotFoundException(`User with ID ${id} not found`);

    await this.userRepository.deleteUserByID(id);
    return true;
  }

  // Delete user by Email
  async deleteUserByEmail(email: string): Promise<boolean> {
    const existing = await this.userRepository.getUserByEmail(email);
    if (!existing) throw new NotFoundException(`User with Email ${email} not found`);

    await this.userRepository.deleteUserByEmail(email);
    return true;
  }

  // Count total users
  async countUsers(): Promise<number> {
    return await this.userRepository.countUsers();
  }
}
