import {
  IsString,
  IsNumber,
  IsBoolean,
  IsOptional,
  IsEmail,
  Min,
  IsIn,
  Matches,
} from 'class-validator';

import { Type } from 'class-transformer';

// Allowed status values
export const VALID_STATUSES = ['Client', 'Employee', 'Admin'] as const;

// =====================
// CREATE USER DTO
// =====================
export class CreateUserDTO {
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  UserID: number;

  @IsString()
  Username: string;

  @IsEmail()
  Email: string;

  // Strong password (similar to express-validator isStrongPassword)
  @IsString()
  @Matches(
    /^(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}$/,
    { message: 'Password must be at least 8 characters long and include numbers & symbols' }
  )
  Password: string;

  @IsString()
  @IsIn(VALID_STATUSES)
  Status: string;
}

// =====================
// UPDATE USER DTO
// =====================
export class UpdateUserDTO {
  @IsOptional()
  @IsString()
  Username?: string;

  @IsOptional()
  @IsEmail()
  Email?: string;

  // Optional strong password (only validate if present)
  @IsOptional()
  @Matches(
    /^(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,}$/,
    { message: 'Password must be at least 8 characters long and include numbers & symbols' }
  )
  Password?: string;

  @IsOptional()
  @IsString()
  @IsIn(VALID_STATUSES)
  Status?: string;
}

// =====================
// PARAM DTOs
// =====================
export class UserIDParam {
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  UserID: number;
}

export class EmailParam {
  @IsEmail()
  Email: string;
}

export class StatusParam {
  @IsString()
  @IsIn(VALID_STATUSES)
  status: string;
}
