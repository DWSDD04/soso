import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  Query,
  NotFoundException,
  HttpCode,
} from '@nestjs/common';

import { UserService } from './user.service';

import { CreateUserDTO } from './dto/create-user.dto';
import { UpdateUserDTO } from './dto/update-user.dto';
import { UserDTO } from './dto/user.dto';

import {
  UserIDParam,
  EmailParam,
  StatusParam,
} from './dto/params.dto';

@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) {}

  // ===============================
  // GET ALL USERS
  // ===============================
  @Get()
  async list(): Promise<UserDTO[]> {
    return this.userService.listUsers();
  }

  // ===============================
  // GET USER BY ID
  // ===============================
  @Get(':UserID')
  async getByID(@Param() params: UserIDParam): Promise<UserDTO> {
    const user = await this.userService.getUserByID(params.UserID);

    if (!user) {
      throw new NotFoundException(`User with ID ${params.UserID} not found`);
    }

    return user;
  }

  // ===============================
  // GET USER BY EMAIL
  // ===============================
  @Get('email/:Email')
  async getByEmail(@Param() params: EmailParam): Promise<UserDTO> {
    const user = await this.userService.getUserByEmail(params.Email);

    if (!user) {
      throw new NotFoundException(`User with Email "${params.Email}" not found`);
    }

    return user;
  }

  // ===============================
  // GET USERS BY STATUS
  // ===============================
  @Get('status/:Status')
  async getByStatus(@Param() params: StatusParam): Promise<UserDTO[]> {
    return this.userService.getUsersByStatus(params.status);
  }

  // ===============================
  // CREATE USER
  // ===============================
  @Post()
  async create(@Body() data: CreateUserDTO): Promise<UserDTO> {
    return this.userService.createUser(data);
  }

  // ===============================
  // UPDATE USER BY ID
  // ===============================
  @Put(':UserID')
  async updateByID(
    @Param() params: UserIDParam,
    @Body() data: UpdateUserDTO,
  ): Promise<UserDTO> {
    const updated = await this.userService.updateUserByID(params.UserID, data);

    if (!updated) {
      throw new NotFoundException(`User with ID ${params.UserID} not found`);
    }

    return updated;
  }

  // ===============================
  // UPDATE USER BY EMAIL
  // ===============================
  @Put('email/:Email')
  async updateByEmail(
    @Param() params: EmailParam,
    @Body() data: UpdateUserDTO,
  ): Promise<UserDTO> {
    const updated = await this.userService.updateUserByEmail(params.Email, data);

    if (!updated) {
      throw new NotFoundException(`User with Email "${params.Email}" not found`);
    }

    return updated;
  }

  // ===============================
  // DELETE USER BY ID
  // ===============================
  @Delete(':UserID')
  @HttpCode(204)
  async deleteByID(@Param() params: UserIDParam): Promise<void> {
    const ok = await this.userService.deleteUserByID(params.UserID);
    if (!ok) {
      throw new NotFoundException(`User with ID ${params.UserID} not found`);
    }
  }

  // ===============================
  // DELETE USER BY EMAIL
  // ===============================
  @Delete('email/:Email')
  @HttpCode(204)
  async deleteByEmail(@Param() params: EmailParam): Promise<void> {
    const ok = await this.userService.deleteUserByEmail(params.Email);
    if (!ok) {
      throw new NotFoundException(`User with Email "${params.Email}" not found`);
    }
  }

  // ===============================
  // COUNT USERS
  // ===============================
  @Get('count')
  async count(): Promise<{ count: number }> {
    const total = await this.userService.countUsers();
    return { count: total };
  }

  // ===============================
  // SEARCH BY EMAIL (optional)
  // ===============================
  @Get('search')
  async search(@Query('q') query: string): Promise<UserDTO[]> {
    if (!query) {
      throw new NotFoundException('Search query "q" is required');
    }
    return this.userService.listUsers(); // you can modify to search by name later
  }
}
