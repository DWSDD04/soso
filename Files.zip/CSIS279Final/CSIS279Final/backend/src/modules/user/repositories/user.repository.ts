import { Injectable } from '@nestjs/common';
import { Repository, DataSource } from 'typeorm';
import { User } from '../entities/user.entity';
import { UserDTO } from '../dto/user.dto';

@Injectable()
export class UserRepository {
  private readonly repo: Repository<User>;

  constructor(private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(User);
  }

  // ============================================
  // CREATE USER
  // ============================================
  async createUser(userDto: UserDTO): Promise<User> {
    const user = this.repo.create(userDto);
    return this.repo.save(user);
  }

  // ============================================
  // GET USER BY ID
  // ============================================
  async getUserByID(UserID: number): Promise<User | null> {
    return this.repo.findOneBy({ UserID });
  }

  // ============================================
  // GET USER BY EMAIL
  // ============================================
  async getUserByEmail(Email: string): Promise<User | null> {
    return this.repo.findOneBy({ Email });
  }

  // ============================================
  // GET USERS BY STATUS
  // ============================================
  async getUserByStatus(Status: string): Promise<User[]> {
    return this.repo.findBy({ Status });
  }

  // ============================================
  // GET ALL USERS
  // ============================================
  async getAllUsers(): Promise<User[]> {
    return this.repo.find();
  }

  // ============================================
  // UPDATE USER BY ID
  // ============================================
  async updateUserByID(
    UserID: number,
    updateData: Partial<UserDTO>,
  ): Promise<void> {
    await this.repo.update({ UserID }, updateData);
  }

  // ============================================
  // UPDATE USER BY EMAIL
  // ============================================
  async updateUserByEmail(
    Email: string,
    updateData: Partial<UserDTO>,
  ): Promise<void> {
    await this.repo.update({ Email }, updateData);
  }

  // ============================================
  // DELETE USER BY ID
  // ============================================
  async deleteUserByID(UserID: number): Promise<void> {
    await this.repo.delete({ UserID });
  }

  // ============================================
  // DELETE USER BY EMAIL
  // ============================================
  async deleteUserByEmail(Email: string): Promise<void> {
    await this.repo.delete({ Email });
  }

  // ============================================
  // COUNT USERS
  // ============================================
  async countUsers(): Promise<number> {
    return this.repo.count();
  }
}
