import { IsString, IsNumber, IsBoolean, IsOptional, Min } from 'class-validator';
import { Type } from 'class-transformer';

// =====================
// DTO for creation
// =====================
export class CreateProductDTO {
  @IsNumber()
  @Min(1)
  ProductID: number;

  @IsString()
  Type: string;

  @IsString()
  Name: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsString()
  Brand: string;

  @IsNumber()
  @Min(0)
  @Type(() => Number)
  CostPrice: number;

  @IsNumber()
  @Min(0)
  @Type(() => Number)
  quantity: number;

  @IsBoolean()
  @Type(() => Boolean)
  Available: boolean;
}

// =====================
// DTO for update
// =====================
export class UpdateProductDTO {
  @IsOptional()
  @IsString()
  Type?: string;

  @IsOptional()
  @IsString()
  Name?: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsOptional()
  @IsString()
  Brand?: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  CostPrice?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  quantity?: number;

  @IsOptional()
  @IsBoolean()
  @Type(() => Boolean)
  Available?: boolean;
}

// =====================
// Param DTOs
// =====================
export class ProductIDParam {
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  ProductID: number;
}

export class NameParam {
  @IsString()
  Name: string;
}

export class TypeParam {
  @IsString()
  Type: string;
}

export class BrandParam {
  @IsString()
  Brand: string;
}

export class AvailableParam {
  @IsBoolean()
  @Type(() => Boolean)
  Available: boolean;
}
