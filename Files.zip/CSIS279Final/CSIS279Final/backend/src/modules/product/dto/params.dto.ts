import { IsString, IsNumberString } from 'class-validator';

// ===============================
// PARAM: ProductID
// ===============================
export class ProductIDParam {
  @IsNumberString()
  ProductID: number;
}

// ===============================
// PARAM: Name
// ===============================
export class NameParam {
  @IsString()
  Name: string;
}

// ===============================
// PARAM: Type
// ===============================
export class TypeParam {
  @IsString()
  Type: string;
}

// ===============================
// OPTIONAL: Brand
// ===============================
export class BrandParam {
  @IsString()
  Brand: string;
}
