import { IsString, IsNumber, IsBoolean, IsOptional } from 'class-validator';

export class CreateProductDTO {
  @IsString()
  Type: string;

  @IsString()
  Name: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsString()
  Brand: string;

  @IsNumber()
  CostPrice: number;

  @IsNumber()
  quantity: number;

  @IsBoolean()
  Available: boolean;
}
