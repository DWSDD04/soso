import { IsString, IsNumber, IsBoolean, IsOptional } from 'class-validator';
import { Product } from '../entities/product.entity';

export class ProductDTO {
  @IsOptional()
  @IsNumber()
  ProductID?: number;

  @IsString()
  Type: string;

  @IsString()
  Name: string;

  @IsOptional()
  @IsString()
  Description?: string;

  @IsString()
  Brand: string;

  @IsNumber()
  CostPrice: number;

  @IsNumber()
  quantity: number;

  @IsBoolean()
  Available: boolean;

  constructor(partial: Partial<ProductDTO>) {
    Object.assign(this, partial);
  }

  // Converts a domain Product entity to a DTO
  static fromEntity(product: Product | null): ProductDTO {
  if (!product) throw new Error('Product is null');
  return new ProductDTO({
    ProductID: product.ProductID,
    Type: product.Type,
    Name: product.Name,
    Description: product.Description,
    Brand: product.Brand,
    CostPrice: product.CostPrice,
    quantity: product.quantity,
    Available: product.Available,
  });
}

}
