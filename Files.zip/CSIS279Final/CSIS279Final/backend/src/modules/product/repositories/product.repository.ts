import { Injectable } from '@nestjs/common';
import { Repository, DataSource } from 'typeorm';
import { Product } from '../entities/product.entity';
import { ProductDTO } from '../dto/product.dto';

@Injectable()
export class ProductRepository {
  private readonly repo: Repository<Product>;

  constructor(private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Product);
  }

  // Create a new product
  async createProduct(productDto: ProductDTO): Promise<Product> {
    const product = this.repo.create(productDto); // converts DTO to entity
    return this.repo.save(product);
  }

  // Get product by ID
  async getProductByID(ProductID: number): Promise<Product | null> {
    return this.repo.findOneBy({ ProductID });
  }

  // Get all products
  async getProducts(): Promise<Product[]> {
    return this.repo.find();
  }

  // Get products by Type
  async getProductByType(Type: string): Promise<Product[]> {
    return this.repo.findBy({ Type });
  }

  // Get products by Name
  async getProductByName(Name: string): Promise<Product[]> {
    return this.repo.findBy({ Name });
  }

  // Get available products
  async getAvailableProducts(Available: boolean): Promise<Product[]> {
    return this.repo.findBy({ Available });
  }

  // Get products by Brand
  async getProductsByBrand(Brand: string): Promise<Product[]> {
    return this.repo.findBy({ Brand });
  }

  // Update product by ID
  async updateProductByID(ProductID: number, updateData: Partial<ProductDTO>): Promise<void> {
    await this.repo.update({ ProductID }, updateData);
  }

  // Update product by Name
  async updateProductByName(Name: string, updateData: Partial<ProductDTO>): Promise<void> {
    await this.repo.update({ Name }, updateData);
  }

  // Update product by Type
  async updateProductByType(Type: string, updateData: Partial<ProductDTO>): Promise<void> {
    await this.repo.update({ Type }, updateData);
  }

  // Update available products
  async updateAvailableProduct(Available: boolean, updateData: Partial<ProductDTO>): Promise<void> {
    await this.repo.update({ Available }, updateData);
  }

  // Delete product by ID
  async deleteProductByID(ProductID: number): Promise<void> {
    await this.repo.delete({ ProductID });
  }

  // Delete product by Name
  async deleteProductByName(Name: string): Promise<void> {
    await this.repo.delete({ Name });
  }

  // Delete product by Type
  async deleteProductByType(Type: string): Promise<void> {
    await this.repo.delete({ Type });
  }
}
