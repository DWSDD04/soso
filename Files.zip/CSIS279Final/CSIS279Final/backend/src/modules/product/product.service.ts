import { Injectable, NotFoundException } from '@nestjs/common';
import { ProductRepository } from './repositories/product.repository';
import { ProductDTO } from './dto/product.dto';
import { ProductServiceRepository } from '../productservice/repositories/productservice.repository';

@Injectable()
export class ProductService {
  constructor(
    private readonly productRepository: ProductRepository,
    private readonly productServiceRepository: ProductServiceRepository, // for linked services
  ) {}

  // Get all products
  async listProducts(): Promise<ProductDTO[]> {
    const products = await this.productRepository.getProducts();
    return products.map(ProductDTO.fromEntity);
  }

  // Get a single product by ID
  async getProductByID(id: number): Promise<ProductDTO | null> {
    const product = await this.productRepository.getProductByID(id);
    return product ? ProductDTO.fromEntity(product) : null;
  }

  // Get products by type
  async getProductsByType(type: string): Promise<ProductDTO[]> {
    const products = await this.productRepository.getProductByType(type);
    return products.map(ProductDTO.fromEntity);
  }

  // Get products by name
  async getProductsByName(name: string): Promise<ProductDTO[]> {
    const products = await this.productRepository.getProductByName(name);
    return products.map(ProductDTO.fromEntity);
  }

  // Get products by brand
  async getProductsByBrand(brand: string): Promise<ProductDTO[]> {
    const products = await this.productRepository.getProductsByBrand(brand);
    return products.map(ProductDTO.fromEntity);
  }

  // Get available products
  async getAvailableProducts(available = true): Promise<ProductDTO[]> {
    const products = await this.productRepository.getAvailableProducts(available);
    return products.map(ProductDTO.fromEntity);
  }

  // Create a new product
  async createProduct(data: ProductDTO): Promise<ProductDTO> {
    const created = await this.productRepository.createProduct(data);
    return ProductDTO.fromEntity(created);
  }

  // Update a product by ID
  async updateProductByID(id: number, data: Partial<ProductDTO>): Promise<ProductDTO> {
    await this.productRepository.updateProductByID(id, data);
    const updated = await this.productRepository.getProductByID(id);
    if (!updated) throw new NotFoundException(`Product with ID ${id} not found`);
    return ProductDTO.fromEntity(updated);
  }

  // Update a product by Name
  async updateProductByName(name: string, data: Partial<ProductDTO>): Promise<ProductDTO[]> {
    await this.productRepository.updateProductByName(name, data);
    const updatedProducts = await this.productRepository.getProductByName(name);
    if (!updatedProducts || updatedProducts.length === 0) {
      throw new NotFoundException(`Product with Name ${name} not found`);
    }
    return updatedProducts.map(ProductDTO.fromEntity);
  }

  // Delete a product by ID (unlink first)
  async deleteProductByID(id: number): Promise<boolean> {
  // Step 1 — check if product exists
  const product = await this.productRepository.getProductByID(id);
  if (!product) return false;

  // Step 2 — unlink services safely
  if (this.productServiceRepository) {
    const linked = await this.productServiceRepository.getServicesForProduct(id);
    if (linked.length > 0) {
      await this.productServiceRepository.deleteByProduct(id);
    }
  }

  // Step 3 — delete
  const result = await this.productRepository.deleteProductByID(id);

  // TypeORM example:
  // return result.affected > 0;

  return true;
}


  // Delete a product by Name
  async deleteProductByName(name: string): Promise<boolean> {
    const products = await this.productRepository.getProductByName(name);
    if (!products || products.length === 0) return false;

    for (const product of products) {
      await this.deleteProductByID(product.ProductID);
    }
    return true;
  }

  // Delete products by Type
  async deleteProductByType(type: string): Promise<boolean> {
    const products = await this.productRepository.getProductByType(type);
    if (!products || products.length === 0) return false;

    for (const product of products) {
      await this.deleteProductByID(product.ProductID);
    }
    return true;
  }
}
