import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  Query,
  NotFoundException,
  HttpCode,
  ParseIntPipe,
} from '@nestjs/common';

import { ProductService } from './product.service';

import { CreateProductDTO } from './dto/create-product.dto';
import { UpdateProductDTO } from './dto/update-product.dto';
import { ProductDTO } from './dto/product.dto';

import {
  ProductIDParam,
  NameParam,
  TypeParam,
} from './dto/params.dto';

@Controller('products')
export class ProductController {
  constructor(private readonly productService: ProductService) {}

  // ===============================
  // SEARCH BY NAME
  // ===============================
  @Get('search')
  async search(@Query('q') query: string): Promise<ProductDTO[]> {
    if (!query) {
      throw new NotFoundException('Search query "q" is required');
    }
    return this.productService.getProductsByName(query);
  }

  // ===============================
  // GET ALL PRODUCTS
  // ===============================
  @Get()
  async list(): Promise<ProductDTO[]> {
    return this.productService.listProducts();
  }

  // ===============================
  // GET BY ID
  // ===============================
  @Get(':ProductID')
  async get(@Param() params: ProductIDParam): Promise<ProductDTO> {
    const product = await this.productService.getProductByID(params.ProductID);
    if (!product) {
      throw new NotFoundException(`Product with ID ${params.ProductID} not found`);
    }
    return product;
  }

  // ===============================
  // CREATE PRODUCT
  // ===============================
  @Post()
  async create(@Body() data: CreateProductDTO): Promise<ProductDTO> {
    return this.productService.createProduct(data);
  }

  // ===============================
  // UPDATE BY ID
  // ===============================
  @Put(':ProductID')
  async updateByID(
    @Param() params: ProductIDParam,
    @Body() data: UpdateProductDTO,
  ): Promise<ProductDTO> {
    const updated = await this.productService.updateProductByID(params.ProductID, data);
    if (!updated) {
      throw new NotFoundException(`Product with ID ${params.ProductID} not found`);
    }
    return updated;
  }

  // ===============================
  // UPDATE BY NAME
  // ===============================
  @Put('name/:Name')
  async updateByName(
    @Param() params: NameParam,
    @Body() data: UpdateProductDTO,
  ): Promise<ProductDTO[]> {
    const updated = await this.productService.updateProductByName(params.Name, data);
    if (!updated || updated.length === 0) {
      throw new NotFoundException(`No products found with Name "${params.Name}"`);
    }
    return updated;
  }

  // ===============================
  // DELETE BY ID
  // ===============================
  @Delete(':ProductID')
@HttpCode(204)
async deleteByID(@Param('ProductID', ParseIntPipe) id: number): Promise<void> {
  const ok = await this.productService.deleteProductByID(id);
  if (!ok) {
    throw new NotFoundException(`Product with ID ${id} not found`);
  }
}


  // ===============================
  // DELETE BY NAME
  // ===============================
  @Delete('name/:Name')
  @HttpCode(204)
  async deleteByName(@Param() params: NameParam): Promise<void> {
    const ok = await this.productService.deleteProductByName(params.Name);
    if (!ok) {
      throw new NotFoundException(`Product with Name "${params.Name}" not found`);
    }
  }

  // ===============================
  // DELETE BY TYPE
  // ===============================
  @Delete('type/:Type')
  @HttpCode(204)
  async deleteByType(@Param() params: TypeParam): Promise<void> {
    const ok = await this.productService.deleteProductByType(params.Type);
    if (!ok) {
      throw new NotFoundException(`No products found for Type "${params.Type}"`);
    }
  }


}
