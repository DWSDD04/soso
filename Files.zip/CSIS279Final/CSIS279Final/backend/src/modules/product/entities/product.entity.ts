import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('products') // table name
export class Product {
  @PrimaryGeneratedColumn()
  ProductID: number;

  @Column()
  Type: string;

  @Column()
  Name: string;

  @Column({ nullable: true })
  Description: string;

  @Column()
  Brand: string;

  @Column('decimal', { precision: 10, scale: 2 })
  CostPrice: number;

  @Column('int')
  quantity: number;

  @Column('boolean', { default: true })
  Available: boolean;

  // optional constructor if you want to use it
  constructor(
    ProductID?: number,
    Type?: string,
    Name?: string,
    Description?: string,
    Brand?: string,
    CostPrice?: number,
    quantity?: number,
    Available?: boolean,
  ) {
    if (ProductID) this.ProductID = ProductID;
    if (Type) this.Type = Type;
    if (Name) this.Name = Name;
    if (Description) this.Description = Description;
    if (Brand) this.Brand = Brand;
    if (CostPrice) this.CostPrice = CostPrice;
    if (quantity) this.quantity = quantity;
    if (Available !== undefined) this.Available = Available;
  }

  // You can still have a static fromRow if needed
 static fromRow(row: any): Product | null {
    if (!row) return null;
    return new Product(
        row.ProductID,
        row.Type,
        row.Name,
        row.Description,
        row.Brand,
        row.CostPrice,
        row.quantity,
        row.Available,
    );
}

}
