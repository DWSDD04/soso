// src/modules/product/product.module.ts
import { Module, forwardRef } from '@nestjs/common'; // you may need forwardRef if circular
import { TypeOrmModule } from '@nestjs/typeorm';
import { Product } from './entities/product.entity';
import { ProductRepository } from './repositories/product.repository';
import { ProductService } from './product.service';
import { ProductController } from './product.controller';

import { ProductServiceModule } from '../productservice/productservice.module'; // import it

@Module({
  imports: [
    TypeOrmModule.forFeature([Product]),
    ProductServiceModule, // <<-- import module that exports ProductServiceRepository
  ],
  controllers: [ProductController],
  providers: [ProductService, ProductRepository],
  exports: [ProductService, ProductRepository],
})
export class ProductModule {}
