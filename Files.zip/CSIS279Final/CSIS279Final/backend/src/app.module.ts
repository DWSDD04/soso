import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { join } from 'path';
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';

import { ProductModule } from './modules/product/product.module';
import { ServiceModule } from './modules/service/service.module';
import { IncomeModule } from './modules/income/income.module';
import { NotificationModule } from './modules/notification/notification.module';


import { Product } from './modules/product/entities/product.entity';
import { Service } from './modules/service/entities/service.entity';
import { Income } from './modules/income/entities/income.entity';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
TypeOrmModule.forRoot({
  type: 'mysql',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT ?? '3306', 10),
  username: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'Mayarima3',
  database: process.env.DB_NAME || 'beautysalon',
  entities: [__dirname + '/**/*.entity.{ts,js}'], // <--- use this
  synchronize: true,
}),

    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      autoSchemaFile: join(process.cwd(), 'src/schema.gql'),
      playground: true,
      sortSchema: true,
      path: '/graphql',
    }),
    ProductModule,
    ServiceModule,
    IncomeModule,
    NotificationModule,
  ],
})
export class AppModule {}
