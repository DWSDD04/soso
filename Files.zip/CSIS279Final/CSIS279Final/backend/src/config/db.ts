// src/config/database.config.ts
import { DataSourceOptions } from 'typeorm';
import * as dotenv from 'dotenv';
import { Service } from '../modules/service/entities/service.entity';
import { Product } from '../modules/product/entities/product.entity';

dotenv.config();

// Ensure all env vars are present, with defaults
const DB_HOST = process.env.DB_HOST ?? 'localhost';
const DB_PORT = process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306;
const DB_USER = process.env.DB_USER ?? 'root';
const DB_PASSWORD = process.env.DB_PASSWORD ?? 'Mayarima3';
const DB_NAME = process.env.DB_NAME ?? 'beautysalon';

export const typeOrmConfig: DataSourceOptions = {
  type: 'mysql',
  host: DB_HOST,
  port: DB_PORT,
  username: DB_USER,
  password: DB_PASSWORD,
  database: DB_NAME,
  entities: [Service, Product],
  synchronize: true, // only for dev, auto-create tables
};
